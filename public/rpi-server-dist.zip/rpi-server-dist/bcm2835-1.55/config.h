/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if you have the `rt' library (-lrt). */
#define HAVE_LIBRT 1

/* Name of package */
#define PACKAGE "bcm2835"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "mikem@airspayce.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "bcm2835"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "bcm2835 1.55"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "bcm2835"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.55"

/* Version number of package */
#define VERSION "1.55"
