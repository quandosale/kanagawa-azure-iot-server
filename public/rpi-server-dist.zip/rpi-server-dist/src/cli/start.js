// var start_server = require('../start_server');
// var daemon = require("daemonize2").setup({
//     main: "../start_server.js",
//     name: "sampleapp",
//     pidfile: "sampleapp.pid"
// });

// var start_service = function (program) {
//     daemon.start();
// };
var GatewayStatus = require('../config').GatewayStatus;
var Util = require('../lib/util');
var Logger = Util.Logger;

var lcd_lib = require('../lcd_lib');

var InfoObj = lcd_lib.InfoObj;
var start_function = function (program) {
    var KanagawaService = require('../KanagawaService').KanagawaService;
    var kanagawaService = new KanagawaService();

    var cookie = kanagawaService.readCookie();
    if (cookie == null) {
        Logger.LOGE('Cannot Start : Cookie is null');
        exit();
    }
    var DEVICE_ID = cookie.deviceId;
    var DEVICE_KEY = cookie.primaryKey;
    var iotHostName = cookie.iotHostName;
    if (DEVICE_ID == null || DEVICE_KEY == null || iotHostName == null) {
        Logger.LOGE(cookie);
        exit();
    }
    kanagawaService.checkAPI(function (status, gateway, error) {
        if (status != GatewayStatus.APPROVED) {
            exit();
        }
        kanagawaService.connectToIotHub(function (isConnect) {
            lcd_lib.connected = isConnect;
            if (!isConnect) {
                lcd_lib.showConnectStatus(false);
                exit();
            }

            lcd_lib.showConnectStatus(true);
        });
    });

};
var exit = function () {
    process.exit(0);
}
module.exports = {
    start_function: start_function,

};