module.exports = {
    COOKIE_PATH: "/usr/myjsonfile_v0.6.json",
    DEFAULT_SERVER_URL: 'https://kanagawa-web.azurewebsites.net',
    GatewayStatus: {
        NOT_REGISTERED: -1,
        NOT_APPROVED: 0,
        APPROVED: 1,
        ERROR: -2
    }
}