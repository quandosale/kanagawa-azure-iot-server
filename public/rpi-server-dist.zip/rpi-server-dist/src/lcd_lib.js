const my_lcd = require('my_lcd_bcm2835');
var network = require('network');
var Logger = require('./lib/util').Logger;
var init = function () {
    my_lcd.init();
};

var clear = function () {

    // var stack = new Error().stack
    // console.log(stack)
    var before = new Date().getTime();
    my_lcd.clear();
    var duration = new Date().getTime() - before;
    // console.log('------------------ clear duration ------------------: ', duration);
    //  my_lcd.fill_white_recg(); // very slow
};

var beforeText = '';
var showText = function (x, y, text, font_size, color, isClear) {
    if (isClear)
        clear();
    my_lcd.drawstring(x, y, text, font_size, color);
};
var show_lines = function (text, color) {
    if (text.includes('undefined') || text == undefined) {
        var stack = new Error().stack
        console.log(stack)
    }
    if (beforeText == text) return;
    clear();
    var text_lines = text.split('\n');
    beforeText = text_lines;

    for (var i = 0; i < text_lines.length; i++) {
        var tmp_line = "" + text_lines[i];
        if (tmp_line.length == 0) continue;
        if (color == null)
            my_lcd.drawstring(10, 20 + 18 * i, tmp_line, 12);
        else
            my_lcd.drawstring(10, 20 + 18 * i, tmp_line, 12, color);

    }
};
var displayCpuInfo = function () {
    clear();
    my_lcd.CpuInfo();
}
var InfoObj = function () {
    this.ip_net_info = '';
    this.connected = null;
    this.arrRegistered = [];
    this.displayIndex - 0;
    this.macListText = '';
    this.nameListText = '';
};

var formatMac = function (mac) {
    if (!mac) return '';
    var result = '';
    for (var i = 0; i < mac.length; i++) {
        result += mac[i];
        if (i % 2 == 1 && i != 0 && i != (mac.length - 1)) {
            result += ':';
        }
    }
    return result.toUpperCase().substr(0, result.length - 6);
};

ip_net_info = '';

InfoObj.prototype.updateDeviceConnectStatus = function (arrConnected) {
    // init connect status
    console.log('------------- update Device Connect Status ---------------- ', arrConnected);
    for (var j = 0; j < this.arrRegistered.length; j++) {
        this.arrRegistered[j].isConnected = false;
    }

    if (arrConnected.length == 0) {
        return;
    }

    for (var i = 0; i < arrConnected.length; i++) {
        for (var j = 0; j < this.arrRegistered.length; j++) {
            if (this.arrRegistered[j].mac == arrConnected[i]) {
                this.arrRegistered[j].isConnected = true;
            }
        }
    }
    if (this.displayIndex == 1) {
        this.displayDevicesMac();
    }
    if (this.displayIndex == 2) {
        this.displayDevicesName();
    }
};

InfoObj.prototype.displayIp = function () {
    if (ip_net_info.length > 0) {
        var text = ip_net_info;
        if (this.connected != null) {
            if (this.connected) {
                text = text + '\nConnected';
            } else {
                text = text + '\nNo Connected'
            }
        }
    }
    show_lines(text);
};
// var CONNECTED_COLOR = 0x07E0;
// var UNCONNECTED_COLOR = 0xF800;
var CONNECTED_COLOR = 0x0000;
var UNCONNECTED_COLOR = 0x0000;

InfoObj.prototype.displayDevicesMac = function (isMust) {
    console.log('displayDevicesMac', isMust)
    if (this.arrRegistered == null) {
        show_lines('Cannot show \nDevices', 0xF800);
        return;
    }
    if (!isMust)
        if (JSON.stringify(this.arrRegistered) == this.macListText) {
            Logger.LOGE('-------- ------------- Mac Equal-------------- ');
            return;
        }
    if (this.arrRegistered.length == 0) {
        show_lines('There is no \nregistered devices', 0xF800);
        return;
    }

    clear();
    for (var i = 0; i < this.arrRegistered.length; i++) {
        if (i == 8) break;
        var tmp_line = formatMac(this.arrRegistered[i].mac);
        my_lcd.drawstring(10, 20 + 15 * i, tmp_line, 12);
        if (this.arrRegistered[i].isConnected)
            my_lcd.DrawCircle(107, 25 + 15 * i, 5, CONNECTED_COLOR, 1);
        // my_lcd.DrawCheck(107, 22 + 15 * i, CONNECTED_COLOR);
        else
            my_lcd.DrawCircle(107, 25 + 15 * i, 5, CONNECTED_COLOR, 0);
        // my_lcd.DrawCheck(107, 22 + 15 * i, UNCONNECTED_COLOR, 1);
    }
    this.macListText = JSON.stringify(this.arrRegistered);
};

InfoObj.prototype.displayDevicesName = function (isMust) {
    console.log('displayDevicesName', isMust)
    if (this.arrRegistered == null) {
        show_lines('Cannot show \nDevices', 0xF800);
        return;
    }
    if (!isMust)
        if (JSON.stringify(this.arrRegistered) == this.macListText) {
            Logger.LOGE('-------- ------------- Name Equal-------------- ');
            return;
        }
    if (this.arrRegistered.length == 0) {
        show_lines('There is no \nregistered devices', 0xF800);
        return;
    }

    clear();
    for (var i = 0; i < this.arrRegistered.length; i++) {
        if (i == 8) break;
        var tmp_line = '' + this.arrRegistered[i].deviceName;
        my_lcd.drawstring(10, 20 + 15 * i, tmp_line, 12);
        if (this.arrRegistered[i].isConnected)
            my_lcd.DrawCircle(107, 25 + 15 * i, 5, CONNECTED_COLOR, 1);
            // my_lcd.DrawCheck(107, 23 + 15 * i, CONNECTED_COLOR);
        else
            my_lcd.DrawCircle(107, 25 + 15 * i, 5, CONNECTED_COLOR, 0);
            // my_lcd.DrawCheck(107, 21 + 15 * i, UNCONNECTED_COLOR, 1);
    }
    this.macListText = JSON.stringify(this.arrRegistered);
};

InfoObj.prototype.display = function () {
    if (this.displayIndex == null) this.displayIndex = 0;
    this.displayIndex = (this.displayIndex + 1) % 4;
    console.log('this.displayIndex', this.displayIndex);
    switch (this.displayIndex) {
        case 0:
            showIp(this.connected);
            break;
        case 1:
            this.displayDevicesMac(true);
            break;
        case 2:
            this.displayDevicesName(true);
            break;
        case 3:
            displayCpuInfo();
            break;

        default:
            showIp(this.connected);
    }
};

var netTypeFormat = function (netType) {
    if (netType == null) return "";
    var strNetType = netType + "";
    if (strNetType.toLocaleLowerCase() == 'wired') {
        return "LAN";
    } else {
        return "WiFi";
    }
};

var showIp = function (ConnectedStatus) {
    network.get_active_interface(function (err, obj) {
        if (err) {
            Logger.LOGE("Cannot get ip address");
            show_lines("Cannot get ip address");
            return;
        }

        var text = netTypeFormat(obj.type) + "\n" + obj.ip_address;
        ip_net_info = text;

        if (ConnectedStatus != null) {
            if (ConnectedStatus) {
                text = text + '\nConnected';
            } else {
                text = text + '\nNo Connected'
            }
        }
        show_lines(text);
    });
};
var showIpFromStatus = function (ConnectedStatus) {
    var text = ip_net_info;

    if (ConnectedStatus != null) {
        if (ConnectedStatus) {
            text = text + '\nConnected';
        } else {
            text = text + '\nNo Connected'
        }
    }
    show_lines(text);
};

var start_step = function () {
    showText(20, 50, "Starting ...", 12, 0xF800, true);
    //my_lcd.LCD_ShowBmp('./assets/calm-logo-start.bmp', 500);
};

var init_step = function () {
    show_lines("Init ...");
};

var showConnectStatus = function (isConnected, url) {
    showIp(isConnected);
};

var showLogo = function () {
    my_lcd.LCD_ShowBmp('/usr/calm-logo.bmp', 2000);
};

module.exports = {
    init: init,
    clear: clear,
    showIpFromStatus: showIpFromStatus,
    showIp: showIp,
    init_step: init_step,
    start_step: start_step,
    showConnectStatus: showConnectStatus,

    // update information property
    show_lines: show_lines,
    InfoObj: InfoObj,
    showLogo: showLogo
};