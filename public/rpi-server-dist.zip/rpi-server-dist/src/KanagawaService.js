
var chalk = require('chalk');
var Util = require('./lib/util');

var request = require("request");
var Logger = require('./lib/util').Logger;
var config = require('./config');

var multiBleManagement = require('./ble/multi');



var ble_entry = multiBleManagement.entry;
var removeDeviceFunction = multiBleManagement.removeDevice;
var addDeviceFunction = multiBleManagement.addDevice;
var startScanningForGet = multiBleManagement.startScanningForGet;

var registeredDevices = [];
var KanagawaService = function () {
    this.cookie = null;
    this.isDisplayIp = true;
};

KanagawaService.prototype.readCookie = function () {
    Logger.LOGD('1. Reading cookie');
    this.cookie = Util.read_cookie();
    if (this.cookie == null) {
        console.log(chalk.red('Cannot read (cookie)'));
        return null;
    }
    return this.cookie;
};
KanagawaService.prototype.onControl = function () {
    var GPIO = require('onoff').Gpio,
        led = new GPIO(18, 'out'),
        buttonReboot = new GPIO(17, 'in', 'both'),
        buttonSwitch = new GPIO(18, 'in', 'both');
    var self = this;
    buttonReboot.watch(function (err, state) {
        if (err) {
            Logger.LOGE(err);
            return;
        }
        // check the state of the button
        // 1 == pressed, 0 == not pressed
        if (state == 1) {
            // turn LED on
            //led.writeSync(1);
            require('child_process').exec('sudo /sbin/shutdown -r now', function (msg) {
                console.log(msg)
            });
        } else {
            // turn LED off
            //led.writeSync(0);
        }

    });

    buttonSwitch.watch(function (err, state) {
        if (err) {
            Logger.LOGE(err);
            return;
        }
        // check the state of the button
        // 1 == pressed, 0 == not pressed
        if (state == 1) {
            self.isDisplayIp = !self.isDisplayIp;
            if (self.isDisplayIp) {
                var ip = require('ip');
                var t = ip.address();
                // lcd display ip
            } else {
                // display Device status
            }
        }
    });

};
var GatewayStatus = config.GatewayStatus;
KanagawaService.prototype.checkAPI = function (callback) {
    if (this.cookie == null) {
        return callback(GatewayStatus.ERROR, null, 'this.cookie == null');
    }

    if (this.cookie.server_url == null) {
        Logger.LOGD(this.cookie);
        return callback(GatewayStatus.ERROR, null, 'this.cookie.server_url == null');
    }

    Logger.LOGD(`2. Check the server ${this.cookie.server_url}`);
    Logger.LOGD(`   with ${this.cookie.deviceId}`);

    var url = `${this.cookie.server_url}/gateways/${this.cookie.deviceId}`;
    var self = this;
    request.get({
            url: url,
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
            },
            json: true
        },
        function (error, response, body) {
            if (!error && response.statusCode == 200) {
                if (body == undefined) {
                    Logger.LOGE("Your Gateway is not registered to server");
                    return process.exit(0);
                }
                if (body.gateway != null) {
                    if (!body.gateway.isApprove) {
                        Logger.LOGE("You have already requested for registration, please wait till server approves your request");
                        var info =
                            `\t server   : ${self.cookie.server_url}\n` +
                            `\t name     : ${body.gateway.name}\n` +
                            `\t id       : ${self.cookie.deviceId}\n` +
                            `\t created  : ${body.gateway.createdAt}\n`;

                        Logger.LOGD(info);
                        return callback(GatewayStatus.NOT_APPROVED);
                    }
                    var devices = body.gateway.devices;

                    for (var i = 0; i < devices.length; i++) {
                        registeredDevices.push({
                            mac: devices[i].mac,
                            deviceName: devices[i].deviceName
                        });
                    }
                } else {
                    Logger.LOGE('Your Gateway Is not registered');
                    return callback(GatewayStatus.NOT_REGISTERED);
                }

                callback(GatewayStatus.APPROVED, body.gateway);
            } else {
                Logger.LOGE("Error on Request for Server");
                Logger.LOGE(error);
                callback(GatewayStatus.ERROR, null, error);
            }
        });
};
var updateMongo = function (server_url, deviceName, deviceId, primaryKey) {
    var url = `${server_url}/gateways`;
    url = url.replace('//gateways', '/gateways');
    request.post({
            url: url,
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
            },
            body: {
                gateway: {
                    name: deviceName,
                    deviceId: deviceId,
                    deviceKey: primaryKey,
                    isApprove: false
                }
            },
            json: true
        },
        function (error, response, body) {
            if (!error && response.statusCode == 200) {
                if (body.isFirstRequestApprove) {
                    Logger.LOGD("Waiting for registration approval from server");
                } else
                if (body.gateway)
                    if (body.gateway.isApprove) {
                        Logger.LOGD("Your gateway is Approved");
                    } else {
                        Logger.LOGD("Still waitng for server to approve this gateway, please try again later");
                    }
                else {
                    //?
                }
            } else {
                Logger.LOGE("error on Request for mongo");
                Logger.LOGE(error);
            }
            process.exit(0);
        });
};
KanagawaService.prototype.checkServer = function (url, callback) {
    request.get({
            url: `${url}/check`,
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
            },
            json: true,
            timeout: 15000
        },
        function (error, response, body) {
            if (!error && response.statusCode == 200) {
                if (body == undefined) return callback(false, null);
                if (body.success) return callback(true, null);
                return callback(false, null);
            } else {
                Logger.LOGE("error on Request for server");
                Logger.LOGE(error);
            }
            return callback(false, error);
        });
};

KanagawaService.prototype.checkLicence = function (url, licence, callback) {
    request.post({
            url: `${url}/request-licence-key`,
            body: {
                key: licence
            },
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
            },
            json: true
        },
        function (error, response, body) {
            if (!error && response.statusCode == 200) {
                if (body == undefined) return callback(false, null, null);
                if (body.success) return callback(true, {
                    iotConnectionString: body.iotConnectionString,
                    iotHostName: body.iotHostName
                }, null);
                return callback(false, null, null);
            } else {
                Logger.LOGE("error on Request for mongo");
                Logger.LOGE(error);
                return callback(false, null, "error on Request for mongo");
            }
            return callback(false, null, error);
        });
};

KanagawaService.prototype.create = function (tmp_cookie) {
    var deviceName = "Gateway";
    if (tmp_cookie.gatewayName)
        deviceName = tmp_cookie.gatewayName;
    if (tmp_cookie.iotConnectionString == null ||
        tmp_cookie.iotConnectionString.length == 0 ||
        tmp_cookie.iotHostName == null ||
        tmp_cookie.iotHostName.length == 0) {
        Logger.LOGE('Cannot find Connecting String for iot-hub');
        Logger.LOGE(tmp_cookie);
        return;
    }

    require('getmac').getMac(function (err, macAddress) {
        if (err) {
            Logger.LOGE('Cannot get mac address.');
            return;
        }
        var device = {
            deviceId: macAddress
        }

        var iothub = require('azure-iothub');
        var registry = iothub.Registry.fromConnectionString(tmp_cookie.iotConnectionString);
        registry.create(device, function (err, deviceInfo, result) {
            if (err) {
                console.log(err.message);
                //?
                registry.get(device.deviceId, function (err, deviceInfo, result) {
                    if (err) {
                        Logger.LOGE('Error Occur while: get device from iot-hub: ' + err.message);
                        return;
                    }
                    if (deviceInfo == null) {
                        Logger.LOGE('deviceInfo is null while: get device from iot-hub: ');
                        return;
                    }
                    tmp_cookie.deviceId = deviceInfo.deviceId;
                    tmp_cookie.primaryKey = deviceInfo.authentication.symmetricKey.primaryKey;


                    Util.write_cookie(tmp_cookie);

                    //Logger.LOGD('Already exist Device On iot-hub: So check the server');
                    updateMongo(tmp_cookie.server_url, deviceName, deviceInfo.deviceId, deviceInfo.authentication.symmetricKey.primaryKey);
                });
            }
            if (deviceInfo) {
                tmp_cookie.deviceId = deviceInfo.deviceId;
                tmp_cookie.primaryKey = deviceInfo.authentication.symmetricKey.primaryKey;
                Util.write_cookie(tmp_cookie);
                updateMongo(tmp_cookie.server_url, deviceName, deviceInfo.deviceId, deviceInfo.authentication.symmetricKey.primaryKey)
                Logger.LOGD('Succssfully created new device :');
                // Logger.LOGD(tmp_cookie);
            }
        });
    });
};

// remove gateway from server/IOThub, & delete cookie
KanagawaService.prototype.remove = function (callback) {
    this.readCookie();
    if (this.cookie == null) {
        process.exit(0);
    }
    Logger.LOGD(`remove ${this.cookie.deviceId}`);
    var url = `${this.cookie.server_url}/gateways/${this.cookie.deviceId}`;
    console.log(url);
    url = url.replace('//gateways', '/gateways');
    console.log(url);
    var self = this;
    request.del(url, {},
        function (error, response, body) {
            console.log('-----------------------------')
            console.log(error);
            if (!error && response.statusCode == 200) {
                // Logger.LOGD(body);

                if (body == undefined) {
                    Logger.LOGE("body == undefined @ remove device");
                    process.exit(0);
                }

                callback(true);
            } else {
                Logger.LOGE("Error on Request for Server");
                Logger.LOGE(error);

                if (response != null)
                    Logger.LOGE("statusCode:" + response.statusCode);
                callback(false);
            }
        });
};

KanagawaService.prototype.connectToIotHub = function (callback) {
    Logger.LOGD('3. Connecting to IotHub client...');
    var DEVICE_ID = this.cookie.deviceId;
    var DEVICE_KEY = this.cookie.primaryKey;
    var connectionString = `HostName=${this.cookie.iotHostName};DeviceId=${DEVICE_ID};SharedAccessKey=${DEVICE_KEY}`;
    var clientFromConnectionString = require('azure-iot-device-mqtt').clientFromConnectionString;
    var client = clientFromConnectionString(connectionString);
    var self = this;
    client.open(function (err) {
        if (err) {
            Logger.LOGE('Could not open IotHub client');
            callback(false);
        } else {
            Logger.LOGD('Create Event for Device Method');
            client.onDeviceMethod('startScan', self.onStartScan);
            client.onDeviceMethod('registerDevices', self.onRegister);
            client.onDeviceMethod('removeDevices', self.onRemove);

            client.on('disconnect', () => {
                Logger.LOGE('client on disconnect called.');
            });

            // if (registeredDevices.length == 0) {
            //     Logger.LOGE("Registered Device Empty");
            //     return;
            // }

            ble_entry(registeredDevices, client);
            callback(true);
        }
    });
};

KanagawaService.prototype.onStartScan = function (request, response) {
    console.log(chalk.red('command:'), ' onStartScan');

    startScanningForGet(function (arr_foundDevices_id) {

        response.send(200, {
            tag: 'FOUND_DEVICES',
            data: arr_foundDevices_id
        }, function (err) {
            if (err) {
                console.error('An error ocurred when sending a method response:\n' + err.toString());
            } else {
                console.log(`Response to method \'${request.methodName}\' sent successfully. with ${arr_foundDevices_id.length}`);
            }
        });
    });
};

KanagawaService.prototype.onRegister = function (request, response) {
    var deviceArr = JSON.parse(request.payload);
    for (var i = 0; i < deviceArr.length; i++) {
        var mac = deviceArr[i].mac;
        var name = deviceArr[i].name;

        registeredDevices.push(deviceArr[i]);
    }
    var isStart = addDeviceFunction(registeredDevices);

    console.log(chalk.red('command:'), ` onRegister: ${deviceArr}`);
    Logger.LOGD(`command: onRegister ${deviceArr}`);
    Logger.LOGD(deviceArr);

    response.send(200, {
        tag: 'ADDED_DEVICES',
        data: deviceArr
    }, function (err) {
        if (err) {
            console.error('An error ocurred when sending a method response:\n' + err.toString());
        } else {
            console.log('Response to method \'' + request.methodName + '\' sent successfully.');
        }
    });
};

KanagawaService.prototype.onRemove = function (request, response) {
    var deviceIds = JSON.parse(request.payload);
    for (var i = 0; i < deviceIds.length; i++) {
        var mac = deviceIds[i];

        var index = -1;
        for (var i = 0; i < registeredDevices.length; i++) {
            if (registeredDevices[i].mac == mac) {
                index = i;
                break;
            }
        }
        console.log('mac removed', mac, 'index = ', index);
        if (index != -1)
            registeredDevices = registeredDevices.splice(index, 1);

        removeDeviceFunction(mac);
    }
    console.log(chalk.red('command:'), ` onRemove:  ${deviceIds}`);

    response.send(200, {
        tag: 'REMOVED_DEVICES',
        data: request
    }, function (err) {
        if (err) {
            console.error('An error ocurred when sending a method response:\n' + err.toString());
        } else {
            console.log('Response to method \'' + request.methodName + '\' sent successfully.');
        }
    });
};

module.exports = {
    KanagawaService: KanagawaService
};