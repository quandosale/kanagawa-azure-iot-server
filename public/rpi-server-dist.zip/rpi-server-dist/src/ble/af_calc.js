const calm_af = require('calm_af');
const AF_STEP = 64;
var AF_Calc = function () {
    this.arr_rri = {};
};

AF_Calc.prototype.add_hr = function (heartRate, mac_from) {
    if (this.arr_rri[mac_from] == undefined) this.arr_rri[mac_from] = [];

    if (heartRate == 0) return 2; //unready
    var rri = 60 / heartRate;
    this.arr_rri[mac_from].push(rri);

    if (this.arr_rri[mac_from].length >= AF_STEP) {
        var arr_tmp = this.arr_rri[mac_from].slice(0, AF_STEP);
        this.arr_rri[mac_from] = this.arr_rri[mac_from].slice(1, this.arr_rri[mac_from].length);
        // console.log(arr_tmp);
        var isAF = calm_af.addAF(arr_tmp);
        return isAF;
    }
    return 2; //unready
};

module.exports = {
    AF_Calc: AF_Calc
}