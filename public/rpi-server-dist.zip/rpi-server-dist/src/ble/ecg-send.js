'use strict';
var chalk = require('chalk');
var sizeof = require('object-sizeof');
var Message = require('azure-iot-device').Message;
var Util = require('../lib/util');
var keys = Object.keys || require('object-keys');
var STEP_DURATION = 10;
var STEP = 250 * STEP_DURATION; // 30 sencods of ecg
var HR_STEP = 10;
var AF_STEP = 10;
var ACC_STEP = STEP / 5;
var FREQUENCE = 250;

var isUploaded = 0;

var EcgSender = function (client) {
    this.arrEcg = {};
    this.HeartRate = {};
    this.AF_result = {};

    this.arrAcc = {
        accX: {},
        accY: {},
        accZ: {}
    };

    this.client = client;
    this.nConnected = 0;
    this.NEED_CONNECT = 0;
    this.isFirst = true;

};

EcgSender.prototype.setHeartRate = function (heartRate, mac_from) {
    if (this.HeartRate[mac_from] == undefined) this.HeartRate[mac_from] = [];
    this.HeartRate[mac_from].push(heartRate);
};
EcgSender.prototype.setAF = function (isAF, mac_from) {
    if (this.AF_result[mac_from] == undefined) this.AF_result[mac_from] = [];
    this.AF_result[mac_from].push(isAF);
};

EcgSender.prototype.add = function (ecg_arr, isSensorDetected, temp, battery, accX, accY, accZ, rssi, mac_from) {
    rssi = rssi || -1000;
    let ecg_length = ecg_arr.length;
    if (this.arrEcg[mac_from] == undefined) this.arrEcg[mac_from] = [];
    if (this.HeartRate[mac_from] == undefined) this.HeartRate[mac_from] = [];
    if (this.AF_result[mac_from] == undefined) this.AF_result[mac_from] = [];

    for (var ecg_index = 0; ecg_index < ecg_length; ecg_index++) {
        var ecg = ecg_arr[ecg_index];
        this.arrEcg[mac_from].push(ecg);
    }

    if (this.arrEcg[mac_from].length < STEP) {
        return;
    }

    var uploadObj_buf = {
        "isSensor": isSensorDetected, // number
        "battery": battery, // number
        "temperature": temp, // number
        "emitter": mac_from, // number
        "pos": -1, // number
        "rssi": rssi, // number
        "ecg": {}, // bufferArray
        "heartrate": {}, // bufferArray
        "af": {} // bufferArray
    };

    //[BEGIN] detect posture
    var acc = Math.sqrt(accX * accX + accY * accY + accZ * accZ);
    if (Math.abs(acc) < 1.1 && Math.abs(acc) > 0.9) {
        if (Math.abs(accZ) >= 0.6) {
            uploadObj_buf["pos"] = 1; //stand
        } else {
            uploadObj_buf["pos"] = 0; //bed
        }
    } else {
        uploadObj_buf["pos"] = 2; //move
    }
    //[END] detect posture

    // [BEGIN] ecg
    var ecgSegment = this.arrEcg[mac_from].slice(0, STEP);
    this.arrEcg[mac_from] = this.arrEcg[mac_from].slice(STEP, this.arrEcg[mac_from].length);

    const buf_ecg = arrayToBuffer12(ecgSegment);

    uploadObj_buf["ecg"] = buf_ecg;
    // [END] ecg

    //[BEGIN] heart rate
    var hr_length = this.HeartRate[mac_from].length;
    var buf_hr = Buffer.allocUnsafe(0);
    if (hr_length % 2 == 0) {
        var hrSegment = this.HeartRate[mac_from].slice(0, HR_STEP);
        this.HeartRate[mac_from] = this.HeartRate[mac_from].slice(HR_STEP, this.HeartRate[mac_from].length);
        buf_hr = arrayToBuffer12(hrSegment);
    } else if (hr_length > 2) {
        Util.Logger.LOGE(`pre hr length = ${hr_length}`);
        hr_length = hr_length - 1;
        var hrSegment = this.HeartRate[mac_from].slice(0, hr_length);
        this.HeartRate[mac_from] = this.HeartRate[mac_from].slice(hr_length, this.HeartRate[mac_from].length);
        buf_hr = arrayToBuffer12(hrSegment);
    }

    uploadObj_buf["heartrate"] = buf_hr;
    //[END] heart rate

    //[BEGIN] AF
    var afSegment = this.AF_result[mac_from].slice(0, AF_STEP);
    this.AF_result[mac_from] = this.AF_result[mac_from].slice(AF_STEP, this.AF_result[mac_from].length);
    const buf_af = arrayToBuffer8(afSegment);

    uploadObj_buf["af"] = buf_af;
    //[END] AF

    this.upload(uploadObj_buf);
};

function arrayToBuffer12(arr_ecg) {
    const buf = Buffer.allocUnsafe(arr_ecg.length / 2 * 3);
    for (var i = 0; i < arr_ecg.length / 2; i += 1) {
        try {
            var first = arr_ecg[i * 2];
            var second = arr_ecg[i * 2 + 1];

            var byte1 = first & 0xFF;
            var byte2 = ((first >> 8) & 0x0F) + (((second >> 8) & 0x0F) << 4);
            var byte3 = second & 0xFF;
            buf.writeUInt8(byte1, 3 * i + 0);
            buf.writeUInt8(byte2, 3 * i + 1);
            buf.writeUInt8(byte3, 3 * i + 2);
        } catch (err) {
            Util.Logger.LOGE('------------------ Error ----------------------')
            Util.Logger.LOGE({
                'byte1': byte1,
                'byte2': byte2,
                'byte3': byte3,
                'i': i,
                'arr_ecg.len': arr_ecg.length,
                'buf.byteLength': buf.byteLength
            });
            Util.Logger.LOGE(err);
        }
    }
    return buf;
}

function arrayToBuffer8(arr_af) {
    const buf = Buffer.allocUnsafe(arr_af.length);
    for (var i = 0; i < arr_af.length; i += 1) {
        var first = arr_af[i];
        var byte1 = first & 0xFF;
        buf.writeUInt8(byte1, i);
    }
    return buf;
}

function buffer12ToArray(buf) {
    var arr_ecg = [];
    for (var i = 0; i < buf.byteLength / 3; i++) {
        var byte1 = buf.readUInt8(i * 3 + 0);
        var byte2 = buf.readUInt8(i * 3 + 1);
        var byte3 = buf.readUInt8(i * 3 + 2);
        // console.log('byte1', byte1, (byte2 & 0x0F) << 8);
        var first = (byte1 & 0xFF) + ((byte2 & 0x0F) << 8);
        var second = (byte3 & 0xFF) + (((byte2 & 0xF0) >> 4) << 8);

        arr_ecg.push(first);
        arr_ecg.push(second);
    }
    return arr_ecg;
}

function printResultFor(op, msg) {
    return function printResult(err, res) {
        if (err) console.log(op + ' error: ' + err.toString());
        if (res) {
            console.log(op + ' status: ' + res.constructor.name, msg);
        }
    };
}

EcgSender.prototype.upload = function (uploadObj) {
    // if (isUploaded == 20) return;
    isUploaded++;

    if (this.client == undefined || this.client == null) {
        console.log("client is not connected");
        return;
    }
    var json = {
        TAG: "ECG",
        data: {
            row: uploadObj,
            duration: STEP_DURATION
        }
    }
    // var buf = Buffer.from(JSON.stringify(json));

    var size = sizeof(json);
    var message = new Message(JSON.stringify(json));

    //let mac_array = keys(this.arrEcg);
    //console.log('mac_array.length', mac_array.length);

    var msg = `(${this.nConnected}/${this.NEED_CONNECT}), size=${size}`;
    this.client.sendEvent(message, printResultFor('upload', msg));
};

module.exports = {
    EcgSender: EcgSender
}