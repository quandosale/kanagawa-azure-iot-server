//
// Created by admin on 5/18/2017.
//

#ifndef SPORTANALYSISTESTER_MYARR_H
#define SPORTANALYSISTESTER_MYARR_H

#include <string>
#include "./common.h"

MyArray rep(FLOAT value, int rep);

void concat(MyArray &a1, FLOAT f);

void concat(MyArray &a1, MyArray a2);

MyArray subArray(MyArray arr, int from, int length);

MyArray subArray(MyArray arr, int from);

MyArray pow2(MyArray a1);

MyArray myfft_half_s_fft(MyArray a1);

MyArray rfftfreq(int n, FLOAT d = 1.0);

MyArray cumsum(MyArray a1);

MyArray percentile(MyArray sequence, MyArray excelPercentile);

MyArray arrayMul(MyArray a1, double v);
//MyArray arrayDiv(MyArray a1, FLOAT v);

MyArray seq(int from, int to);

MyArray seqWithMul(int from, int to, FLOAT mul);

FLOAT *myArrToFLOAT(MyArray a1);

MyArray arrFloatToMyArr(FLOAT *arrFloat);

FLOAT min(MyArray a);

FLOAT max(MyArray a);

FLOAT sum(MyArray a);

FLOAT sum(FLOAT f1, FLOAT f2, FLOAT f3);

FLOAT sum(FLOAT f1, FLOAT f2);

FLOAT max(FLOAT f1, FLOAT f2, FLOAT f3);

FLOAT min(FLOAT f1, FLOAT f2, FLOAT f3);

FLOAT two_max(FLOAT f1, FLOAT f2);

FLOAT two_min(FLOAT f1, FLOAT f2);



//MyArray condition1(MyExArray exArray);

MyArray condition_lf(MyExArray exArray);

MyArray condition_hf(MyExArray exArray);

DataFrame filter_by_rri(DataFrame df, FLOAT from, FLOAT to);

MyArray
interpolate(MyArray &xData, MyArray &yData, bool extrapolate, FLOAT min, FLOAT max);

void show(MyArray a1);

void show(MyArray a1, string strFilter); // show array with filter(Log filterHR)
void show(MyArray a1, int from, int _len);

MyExArray subsetC1(MyExArray exArray);

MyExArray subsetC2(MyExArray exArray);

MyExArray subsetC3(MyExArray exArray);

void detrend_IP(MyArray &y, int m);

MyArray getByIndexArr(MyArray dataArr, MyArray indexArr);

int length(MyArray a);

int length(MyExArray a);

MyExArray frame(MyArray a1, MyArray a2);

int nrow(MyExArray aEx);

int length(My6Array a6);
#include <algorithm>
#include <string.h>
// #include "MyArr.h"
#include "./fft.h"

MyArray cumsum(MyArray a1) {
    MyArray data;
    long len = a1.size();
    FLOAT prevValue = 0;
    for (unsigned long i = 0; i < len; i++) {
        prevValue = prevValue + a1[i];
        data.push_back(prevValue);
    }
    return data;
}

MyArray subArray(MyArray arr, int from, int length) {
    MyArray data;

    int until = from + length;
    for (unsigned int i = (unsigned int) from; i < until; ++i) {
        data.push_back((FLOAT) arr[i]);
    }

    return data;
}

MyArray subArray(MyArray arr, int from) {
    MyArray data;
    unsigned long len = arr.size();

    for (unsigned int i = (unsigned int) from; i < len; ++i) {
        data.push_back((FLOAT) arr[i]);
    }
    return data;
}

MyArray pow2(MyArray a1) {
    MyArray data;
    unsigned long len = a1.size();
    for (unsigned int i = 0; i < len; ++i) {
        data.push_back(a1[i] * a1[i]);
    }
    return data;
}


MyArray myfft_half_s_fft(MyArray a1) {
    MyArray result;
        size_t nfft = a1.size();
        if (nfft == 0)return result;
        FLOAT *real = (FLOAT*)malloc(nfft * sizeof (FLOAT));
        FLOAT *img = (FLOAT*)malloc(nfft * sizeof (FLOAT));
        memset(img, 0, nfft);
//        real = a1.data();
        for(int i = 0;i<nfft;i++){
            real[i] = a1[i];
        }

        Fft_transform(real, img, nfft);
        int k = 0;
        for (k = 0; k < nfft / 2 + 1; ++k) {
            FLOAT value = real[k] * real[k] + img[k] * img[k];
            result.push_back(value);
        }
        free(real);
        free(img);

   
    return result;
}


MyArray rfftfreq(int n, FLOAT d) {
    FLOAT val = 1.0 / (n * d);
    int N = (n / 2) + 1;
    MyArray result;
    for (unsigned long i = 0; i < N; i++) {
        result.push_back(i * val);
    }
    return result;
}
//MyArray fft(MyArray a1) {
//    CFourier fft;
//    FLOAT *data = myArrToFLOAT(a1);
//    LOGD("----------------fft test BEGIN----------------");
//    for (unsigned int i = 0; i < 20; ++i) {
//        LOGD("float test %f", data[i]);
//    }
//    fft.ComplexFFT(data,a1.size(), a1.size(),1);
//    LOGD("----------------fft test AFTER----------------");
//    for (unsigned int i = 0; i < 20; ++i) {
//        LOGD("float test %f", data[i]);
//    }
//    LOGD("----------------fft test   END----------------");
//    return a1;
//}

MyArray rep(FLOAT value, int rep) {
    MyArray data;
    for (unsigned int i = 0; i < rep; i++) {
        data.push_back(value);
    }
    return data;
}

void concat(MyArray &a1, MyArray a2) {

    unsigned long len2 = a2.size();
    for (unsigned int i = 0; i < len2; i++) {
        a1.push_back((FLOAT) a2[i]);
    }

}

void concat(MyArray &a1, FLOAT f) {
    a1.push_back(f);
}

MyArray arrayMul(MyArray &a1, double v) {
    MyArray data;
    int len = a1.size();
    for (unsigned int i = 0; i < len; i++) {
        data.push_back(a1[i] * v);
    }
    return data;
}

MyArray seq(int from, int to) {
    MyArray data;
    for (unsigned int i = from; i <= to; ++i) {
        data.push_back((FLOAT) i);
    }
    return data;
}

MyArray seqWithMul(int from, int to, FLOAT mul) {
    MyArray data;
    for (unsigned int i = from; i <= to; ++i) {
        data.push_back(i * mul);
    }
    return data;
}

int length(MyArray a) {
    return a.size();
}

FLOAT *myArrToFLOAT(MyArray a1) {
    FLOAT *arrFLOAT;
    int len = a1.size();
    arrFLOAT = new FLOAT[len];
    for (unsigned int i = 0; i < len; i++) {
        arrFLOAT[i] = a1[i];
    }
    return arrFLOAT;
}

FLOAT sum(MyArray a) {
    FLOAT data = 0;
    int len = a.size();
    for (unsigned int i = 0; i < len; ++i) {
        data += a[i];
    }
    return data;
}

MyExArray frame(MyArray a1, MyArray a2) {
    MyExArray data;
    long len1 = a1.size();
    long len2 = a2.size();
    if (len1 != len2) {
        return data;
    }
    for (unsigned int i = 0; i < len1; ++i) {
        data.freq.push_back((FLOAT) a1[i]);
        data.spec.push_back((FLOAT) a2[i]);
    }
    return data;
}

int nrow(MyExArray aEx) {
    return (int) aEx.freq.size();
}

FLOAT sum(FLOAT f1, FLOAT f2, FLOAT f3) {
    return f1 + f2 + f3;
}

FLOAT sum(FLOAT f1, FLOAT f2) {
    return f1 + f2;
}

MyArray arrFloatToMyArr(FLOAT *arrFloat) {
    MyArray result;
    int len = sizeof(arrFloat) / sizeof(arrFloat);

    for (int i = 0; i < len; i++) {
        result.push_back(arrFloat[i]);
    }
    return result;
}

FLOAT min(MyArray a) {
    long len = a.size();
    if (len == 0)return 0;
    FLOAT fmin = a[0];
    for (int i = 1; i < len; i++) {
        if (fmin > a[i])fmin = a[i];
    }
    return fmin;
}

FLOAT max(MyArray a) {
    long len = a.size();
    if (len == 0)return 0;
    FLOAT fmax = a[0];
    for (int i = 1; i < len; i++) {
        if (fmax < a[i])fmax = a[i];
    }
    return fmax;
}

bool myfunction(int i, int j) { return (i < j); }

MyArray percentile(MyArray sequence, MyArray excelPercentile) {
//    Array.Sort(sequence);

    MyArray result;
    
//        unsigned long len = sequence.size();
//        for (unsigned long i = 0; i < len - 1; i++) {
//            for (unsigned long j = i + 1; j < len; j++) {
//                if (sequence[i] > sequence[j]) {
//                    FLOAT tmp = sequence[i];
//                    sequence[i] = sequence[j];
//                    sequence[j] = tmp;
//                }
//            }
//        }
        std::sort(sequence.begin(), sequence.end());
//        std::sort(sequence.begin() + 4, sequence.end(), myfunction);

        long len_excel = excelPercentile.size();
        for (unsigned long i = 0; i < len_excel; i++) {
            FLOAT fResult = 0;
            unsigned long N = sequence.size();
            double n = (N - 1) * excelPercentile[i] + 1;
            // Another method: double n = (N + 1) * excelPercentile;
            if (n == 1) result.push_back((FLOAT) sequence[0]);
            else if (n == N) result.push_back((FLOAT) sequence[N - 1]);
            else {
                unsigned long k = (unsigned long) n;
                double d = n - k;
                result.push_back(
                        (FLOAT) sequence[k - 1] + d * (sequence[k] - sequence[k - 1]));
            }

        }
    return result;

}

FLOAT max(FLOAT f1, FLOAT f2, FLOAT f3) {
    FLOAT r1 = 0;
    if (f1 < f2)r1 = f2;
    else r1 = f1;
    if (r1 < f3)r1 = f3;
    return r1;
}

FLOAT min(FLOAT f1, FLOAT f2, FLOAT f3) {
    FLOAT r1 = 0;
    if (f1 > f2)r1 = f2;
    else r1 = f1;
    if (r1 > f3)r1 = f3;
    return r1;
}

FLOAT two_max(FLOAT f1, FLOAT f2) {
    if (f1 < f2)return f2;
    return f1;
}

FLOAT two_min(FLOAT f1, FLOAT f2) {
    if (f1 > f2)return f2;
    return f1;
}

int length(My6Array a6) {
    return a6.ar_vlf_sum.size();
}

int length(MyExArray a) {
    return a.freq.size();
}

MyArray getByIndexArr(MyArray dataArr, MyArray indexArr) {
    MyArray data;
    int len = length(indexArr);
    for (unsigned int i = 0; i < len; i++) {
//      LOGD("for index %d length %d",i,length(data));
        data.push_back((FLOAT) dataArr[(unsigned int) indexArr[i]]);
    }
    return data;
}

//MyArray condition1(MyExArray exArray) {
//    MyArray data;
//    int len = length(exArray);
//    for (unsigned int i = 0; i < len; i++) {
//        if (exArray.freq[i] >= 0.003 && exArray.freq[i] < 0.04) {
//            data.push_back(exArray.spec[i]);
//        }
//    }
//    return data;
//}

MyArray condition_lf(MyExArray exArray) {
    MyArray data;
    int len = length(exArray);
    for (unsigned int i = 0; i < len; i++) {
        if (0.04 <= exArray.freq[i] && exArray.freq[i] < 0.15) {
            data.push_back((FLOAT) exArray.spec[i]);
        }
    }
    return data;
}


MyArray condition_hf(MyExArray exArray) {
    MyArray data;
    int len = length(exArray);
    for (unsigned int i = 0; i < len; i++) {
        if (0.15 <= exArray.freq[i] && exArray.freq[i] < 0.40) {
            data.push_back((FLOAT) exArray.spec[i]);
        }
    }
    return data;
}

DataFrame filter_by_rri(DataFrame df, FLOAT from, FLOAT to) {
    DataFrame df_result;
    size_t size = df.rri.size();
    for (size_t i = 0; i < size; i++) {
        if (from <= df.rri[i] && df.rri[i] <= to) {
            df_result.index.push_back(df.index[i]);
            df_result.rri.push_back(df.rri[i]);
        }
    }
    return df_result;
}

// Returns interpolated value at x from parallel arrays ( xData, yData )
//   Assumes that xData has at least two elements, is sorted and is strictly monotonic increasing
//   boolean argument extrapolate determines behaviour beyond ends of array (if needed)

MyArray interpolate(MyArray &xData, MyArray &yData, bool extrapolate, FLOAT min, FLOAT max) {
    int size = xData.size();
    int i = 0;                                                       // find left end of interval for interpolation
    MyArray result;
    for (FLOAT x = min; x < max; x++) {
        if (x >= xData[size -
                       2])                                           // special case: beyond right end
        {
            i = size - 2;
        } else {
            while (x > xData[i + 1]) i++;
        }
        double xL = xData[i],
                yL = yData[i],
                xR = xData[i + 1],
                yR = yData[i + 1];                                   // points on either side (unless beyond ends)
        if (!extrapolate)                                            // if beyond ends of array and not extrapolating
        {
            if (x < xL) yR = yL;
            if (x > xR) yL = yR;
        }

        double dydx = (yR - yL) / (xR - xL);                        // gradient

        result.push_back(yL + dydx * (x - xL));                     // linear interpolation
    }//for
    return result;
}

MyExArray subsetC1(MyExArray exArray) {
    MyExArray result;
    int len = length(exArray);

    for (unsigned int i = 0; i < len; i++) {
        if (exArray.freq[i] >= 0.003 && exArray.freq[i] <= 0.04) {
            result.spec.push_back((FLOAT) exArray.spec[i]);
            result.freq.push_back((FLOAT) exArray.freq[i]);
        }
    }
    return result;
}

MyExArray subsetC2(MyExArray exArray) {
    MyExArray result;
    int len = length(exArray);
    for (unsigned int i = 0; i < len; i++) {
        if (exArray.freq[i] >= 0.04 && exArray.freq[i] < 0.15) {
            result.spec.push_back((FLOAT) exArray.spec[i]);
            result.freq.push_back((FLOAT) exArray.freq[i]);
        }
    }
    return result;
}

MyExArray subsetC3(MyExArray exArray) {
    MyExArray result;
    int len = length(exArray);
    for (unsigned int i = 0; i < len; i++) {
        if (exArray.freq[i] >= 0.15 && exArray.freq[i] < 0.40) {
            result.spec.push_back((FLOAT) exArray.spec[i]);
            result.freq.push_back((FLOAT) exArray.freq[i]);
        }
    }
    return result;
}

void show(MyArray a1) {
    int len = length(a1);
    for (unsigned int i = 0; i < len; ++i) {
        LOGE("%d      %f", i, a1[i]);
    }
}

void detrend_IP(MyArray &y, int m) {
    FLOAT xmean, ymean;
    int i;
    FLOAT temp;
    FLOAT Sxy;
    FLOAT Sxx;

    FLOAT grad;
    FLOAT yint;

    MyArray x;

    /********************************
    Set the X axis Liner Values
    *********************************/
    for (i = 0; i < m; i++)
        x.push_back((FLOAT) i);

    /********************************
    Calculate the mean of x and y
    *********************************/
    xmean = 0;
    ymean = 0;
    for (i = 0; i < m; i++) {
        xmean += x[i];
        ymean += y[i];
    }
    xmean /= m;
    ymean /= m;

    /********************************
    Calculate Covariance
    *********************************/
    temp = 0;
    for (i = 0; i < m; i++)
        temp += x[i] * y[i];
    Sxy = temp / m - xmean * ymean;

    temp = 0;
    for (i = 0; i < m; i++)
        temp += x[i] * x[i];
    Sxx = temp / m - xmean * xmean;

    /********************************
    Calculate Gradient and Y intercept
    *********************************/
    grad = Sxy / Sxx;
    yint = -grad * xmean + ymean;

    /********************************
    Removing Linear Trend
    *********************************/
    for (i = 0; i < m; i++)
        y[i] = y[i] - (grad * i + yint);

}

void show(MyArray a1, string strFilter) {
    int len = length(a1);
    for (unsigned int i = 0; i < len; ++i) {
        LOGE("%s      %7d      %.8f", strFilter.c_str(), i, a1[i]);
    }
}

void show(MyArray a1, int from, int _len) {
    int to = from + _len;
    int len = length(a1);
    if (to > len) {
        to = len;
    }
    for (unsigned int i = (unsigned int) from; i < to; ++i) {
        LOGD("arr_range     %7d      %f", i, a1[i]);
    }
}

#endif //SPORTANALYSISTESTER_MYARR_H
