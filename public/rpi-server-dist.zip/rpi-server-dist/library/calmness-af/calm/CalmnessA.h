//
// Created by admin on 8/10/2017.
//

#ifndef SPORTANALYSISTESTER_TEST_H
#define SPORTANALYSISTESTER_TEST_H

#include "common.h"
#include "MyArr.h"
#include "Header.h"

namespace Calm {
	struct CalmnessA {

		FLOAT needDataPercent = 0;

		int window_size = 250 * 120; // 5 minutes
		int interval = 250 * 10;// 1
		int samplingfreq = 250;
		double Calmness_Min = -30;
		double Calmness_Max = 100;
		MyArray g_queueIRRI;

		MyArray m_arr_rri;
		int RRI_LIMIT = 10;
		bool isFake = true;

		void clear() {
			m_arr_rri.clear();
			g_queueIRRI.clear();
		}

		void clear(bool needFake) {
			m_arr_rri.clear();
			g_queueIRRI.clear();
			isFake = needFake;
		}

		MyArray calmnessDataSrc(MyArray RRI) {
			MyArray arrNull; // for break
			// try {
				//2. Generate IRRI from RRI data
				int allLength = length(RRI);
				LOGE("---------------- rri -----------calmness Data Src size %d",
					allLength);
				unsigned long RRI_len = RRI.size();
				for (unsigned long i = 0; i < RRI_len; i++) {
					m_arr_rri.push_back(RRI[i]);
				}
				int arr_rri_size = m_arr_rri.size();
				if (arr_rri_size < RRI_LIMIT) {
					LOGE("still not enough RRI           need = %d, current = %d", RRI_LIMIT,
						arr_rri_size);
					return arrNull;
				}

				MyArray arr_rri;
				for (unsigned long i = 0; i < arr_rri_size; i++) {
					arr_rri.push_back(m_arr_rri[i]);
				}
				m_arr_rri.clear();
				MyArray IRRI = Import_RRI(arr_rri);
				LOGE("---------------- irri -----------calmness Data Src size %d", IRRI.size());

				MyArray rr = process_cal(IRRI);
				return rr;
			// }
			// catch (const std::exception &e) {
			// 	LOGE("sleep_debug     error occur on calmness   %s", e.what());
			// }
			return arrNull;
		}

		MyArray filtering(MyArray IRRI) {
			// try {
				// Filtering Outliers with Relative Value

				long len_IRRI = IRRI.size();
				DataFrame df_frame;
				for (size_t i = 0; i < len_IRRI; i++) {
					df_frame.index.push_back((FLOAT)i);
					df_frame.rri.push_back((FLOAT)IRRI[i]);
				}

				MyArray arrPercent;
				arrPercent.push_back(0.25);
				arrPercent.push_back(0.75);

				MyArray q25q75 = percentile(IRRI, arrPercent);
				show(q25q75, "q2575");
				FLOAT q25 = 0;
				FLOAT q75 = 0;

				if (q25q75.size() >= 2) {
					q25 = q25q75[0];
					q75 = q25q75[1];
				}

				FLOAT iqr = q75 - q25;
				FLOAT from = q25 - 1.5 * iqr;
				FLOAT to = q75 + 1.5 * iqr;
				LOGE("filter_func   length = %d   q25 = %f  q75 = %f,  from = %f, to = %f",
					len_IRRI, q25,
					q75, from, to);

				DataFrame df2_frame = filter_by_rri(df_frame, from, to);
				// Filtering Outliers with Absolute Value
				DataFrame df3_frame = filter_by_rri(df2_frame, 0.2, 2);


				unsigned long len_df3 = df3_frame.rri.size();
				if (len_df3 <= 2) {
					LOGE("len_df4 size <= 2,     size = %ld", len_df3);
					return df3_frame.rri;
				}

				std::deque<double> df3_X((unsigned int)len_df3);
				std::deque<double> df3_Y(
					(unsigned int)len_df3);//Y(rri_array, rri_array + len_IRRI);

				for (unsigned long i = 0; i < len_df3; i++) {
					df3_X[i] = df3_frame.index[i];
					df3_Y[i] = df3_frame.rri[i];
				}

				FLOAT df3_frame_min = min(df3_frame.index);
				FLOAT df3_frame_max = max(df3_frame.index);

				//                FLOAT range = df3_max - df3_min;


				LOGD("interpolate ...");
				MyArray return_IRRI =
					interpolate(df3_X, df3_Y, false, df3_frame_min, df3_frame_max);


				LOGD("detrend ...");
				detrend_IP(return_IRRI, (int)return_IRRI.size());

				LOGE("filter_func   from %ld,  to %ld", len_IRRI, return_IRRI.size());
				return return_IRRI;
			// }
			// catch (const std::exception &e) {
			// 	LOGE("filter_func error occur : percentile   %s", e.what());
			// }
			return IRRI;
		}

		MyArray Import_RRI(MyArray rri_array) {
			unsigned int len = (unsigned int)length(rri_array);
			LOGE("Import_RRI from %d", len);
			std::deque<double> X(len), Y(len);//Y(rri_array, rri_array + len);
			MyArray result;

			MyArray arr_cumsum = cumsum(rri_array);
			FLOAT minValue = min(arr_cumsum);
			FLOAT maxValue = max(arr_cumsum);
			LOGE("min = %lf, max = %fl", minValue, maxValue);
			for (int i = 0; i < len; i++) {
				X[i] = arr_cumsum[i];
				Y[i] = rri_array[i];
			}
			show(X, "x");

			tk::spline s;
			s.set_points(X, Y);    // currently it is required that X is already sorted

			int index = 0;
			for (double i = minValue; i < maxValue; i += 1 / double(250)) {
				double num = s(i);
				result.push_back(num);
			}
			if (isFake) {
				isFake = false;
				MyArray arrTan;
				for (int i = 0; i < 120 * 250; i++) {
					FLOAT tanValue = tan(i);
					arrTan.push_back(tanValue);
				}
				//            show(result, 0, 10000);
				LOGE("Import_RRI to %ld", result.size());
				concat(arrTan, result);
				LOGE("Import_RRI to %ld", arrTan.size());
				return arrTan;
			}
			else {
				return result;
			}
		}

		FLOAT getCalmnessDataPercent() {
			return needDataPercent;
		}

		MyArray process_cal(MyArray IRRI) {
			MyArray arrNull; // for break
							 // Calculate
			// try {
				MyArray ar_lf_sum;
				MyArray ar_hf_sum;

				MyArray ar_lf_dif;
				MyArray ar_hf_dif;

				concat(g_queueIRRI, IRRI); // push to Global queue
				int count = length(g_queueIRRI) - window_size;
				int nTimes = count / interval;
				needDataPercent = int(double(count) * 100 / double(interval));
				//
				LOGE("calmness_algo: count = %d, g_queueIRRI = %d nTimes= %d  percent = %f", count,
					length(g_queueIRRI),
					nTimes, needDataPercent);

				if (count <= 0 || nTimes <= 0) {
					return arrNull;
				}

				//                nTimes = 1;
				for (unsigned int i = 0; i < nTimes * interval; i += interval) {

					MyArray irri = subArray(g_queueIRRI, i, window_size);
					LOGE("calc calmness %d  %d  %d, len(irri) = %d", i, nTimes * interval, interval,
						length(irri));
					MyArray IRRI2 = filtering(irri);// filtering(IRRI[range(i, i+ window)])
					if (IRRI2.size() == 0)continue;
					MyReturnValue LFHF_repo = LFHF(IRRI2, length(IRRI2));
					LOGD("LFHF_repo.lf_sum %f", LFHF_repo.lf_sum);
					LOGD("LFHF_repo.hf_sum %f", LFHF_repo.hf_sum);
					LOGD("LFHF_repo.lf_dif %f", LFHF_repo.lf_dif);
					LOGD("LFHF_repo.hf_dif %f", LFHF_repo.hf_dif);

					concat(ar_lf_sum, LFHF_repo.lf_sum);
					concat(ar_hf_sum, LFHF_repo.hf_sum);

					concat(ar_lf_dif, LFHF_repo.lf_dif);
					concat(ar_hf_dif, LFHF_repo.hf_dif);
				}
				//            LOGE1("calmness_algo: remove From First %d %d, %d", length(g_queueIRRI),
				//                  nTimes * interval,
				//                  length(g_queueIRRI) - nTimes * interval);
				g_queueIRRI = subArray(g_queueIRRI, nTimes * interval);

				// calculate calmness score
				int len = length(ar_lf_sum);
				MyArray calmness;

				for (unsigned int i = 0; i < len; i++) {
					FLOAT __sum = sum(ar_lf_sum[i], ar_hf_sum[i]);
					if (__sum == 0)__sum = 1;
					FLOAT PR = (
						max(ar_lf_sum[i], ar_hf_sum[i])
						-
						min(ar_lf_sum[i], ar_hf_sum[i])
						)
						/ __sum;

					FLOAT __sum2 = sum(ar_lf_dif[i], ar_hf_dif[i]);
					if (__sum2 == 0)__sum2 = 1;
					FLOAT DR = (
						max(ar_lf_dif[i], ar_hf_dif[i])
						-
						min(ar_lf_dif[i], ar_hf_dif[i])
						)
						/ __sum2;
					FLOAT calmness_sub = (PR / 2 + DR / 2) * 100;
					FLOAT calm =
						(calmness_sub - Calmness_Min) / (Calmness_Max - Calmness_Min) * 100;

					if (calm > 100)calm = 100;
					if (calm < 0)calm = 0;
					calmness.push_back(calm);
					LOGI("calmness_2               calm2 = %f", calm);
				}
				return calmness;
			// }
			// catch (const std::exception &e) {
			// 	LOGE("calmnessAlgo error occur %s ", e.what());
			// }
			return arrNull;
		}

		MyReturnValue LFHF(MyArray data, int window_size) {
			MyReturnValue rtn;
			// try {
				FLOAT samplingperiod = 1.0 / samplingfreq;
				MyArray freq = rfftfreq(window_size, samplingperiod);
				MyArray spec = myfft_half_s_fft(
					data); // calculate abs(fft(data)) ^ 2 in fft() function
				MyExArray PS = frame(freq, spec);
				MyArray lf_array = condition_lf(PS);
				MyArray hf_array = condition_hf(PS);
				LOGD("lf_array %d", length(lf_array));
				LOGD("hf_array %d", length(hf_array));

				FLOAT lf_sum = sum(lf_array);
				lf_sum = lf_sum * samplingperiod / 2;
				FLOAT hf_sum = sum(hf_array);
				hf_sum = hf_sum * samplingperiod / 2;

				FLOAT lf_dif = 0;

				double lf_length = length(lf_array);
				if (lf_length > 0)
					for (unsigned int x = 0; x < (lf_length - 1); x++) {
						lf_dif += abs(lf_array[x + 1] - lf_array[x]);
					}

				FLOAT hf_dif = 0;

				double hf_length = length(hf_array);
				if (hf_length > 0)
					for (unsigned int x = 0; x < (hf_length - 1); x++) {
						hf_dif += abs(hf_array[x + 1] - hf_array[x]);
					}

				rtn.lf_sum = lf_sum;
				rtn.hf_sum = hf_sum;
				rtn.lf_dif = lf_dif;
				rtn.hf_dif = hf_dif;
			// }
			// catch (const std::exception &e) {
			// 	LOGE("Error occur at calmness LFHF %s,", e.what());
			// }
			return rtn;
		}
	};
}
#endif //SPORTANALYSISTESTER_TEST_H
