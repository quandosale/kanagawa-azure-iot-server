#ifndef ex_ecg_common_H
#define ex_ecg_common_H

#include <deque>

using namespace std;

#include <cmath>

#include <vector>

//#define ENABLE_DEBUG_LOG false

#ifdef ENABLE_DEBUG_LOG
#define  LOG_TAG    "C_TAG"
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)
#define  LOGW(...)  __android_log_print(ANDROID_LOG_WARN,LOG_TAG,__VA_ARGS__)
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#endif
#ifndef ENABLE_DEBUG_LOG
#define  LOGD(...)  {}
#define  LOGE(...)  {}
#define  LOGW(...)  {}
#define  LOGI(...)  {}
#endif


typedef double FLOAT;
typedef deque<FLOAT> MyArray;
typedef deque<MyArray> TwoArray;

typedef struct _test {
    MyArray freq;
    MyArray spec;
} MyExArray;

typedef struct _dataFrame {
    MyArray index;
    MyArray rri;
} DataFrame;

typedef struct _returnValue {
    FLOAT lf_sum, hf_sum, lf_dif, hf_dif;
} MyReturnValue;
typedef struct _My6Array {
    MyArray ar_vlf_sum, ar_lf_sum, ar_hf_sum, ar_vlf_dif, ar_lf_dif, ar_hf_dif;
} My6Array;

#endif
