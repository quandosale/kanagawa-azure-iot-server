#include "common.h"

#ifndef af_detect_H
#define af_detect_H
#include <cmath>

#include "MyArr.h"
#include <string.h>
namespace AF_Module {
	struct AF_Detect {

		MyArray intercept1, intercept2, intercept3;

		TwoArray coefs1, coefs2, coefs3;

		void show(TwoArray arr, string title = "matrix show") {
			int len = arr.size();
			if (len == 0)return;
			int rowLen = arr.at(0).size();
			LOGE("------------------------ out put maxtix( %s ): size = %d * %d ---------------------------",
				title.c_str(), len, rowLen);
			//for (unsigned int i = 0; i < len; i++) {
			//    string row = "row: " + ntocs(i) + ": ";
			//    for (unsigned j = 0; j < rowLen; j++) {
			//        row += ftocs(arr.at(i).at(j)) + ", ";
			//    }
			//    LOGE("%s", row.c_str());
			//}
		}

		void show(MyArray a1, string strFilter) {
			int len = length(a1);
			for (unsigned int i = 0; i < len; ++i) {
				printf("%s      %d      %.8f\n", strFilter.c_str(), i, a1.at(i));
			}

		}


		void init() {
			double inter1[] = { -5.358892273894475533e-01,
							   -3.303834806707225957e-01,
							   -7.277608766665112361e-01,
							   9.816729213477963512e-02,
							   1.443826657210534221e-02,
							   -3.165055777187497643e-01,
							   2.438705860282272264e-01,
							   3.142969049745092947e-01,
							   4.041830055735944893e-01,
							   -1.194205793116955988e-01
			};
			double inter2[] = {
					-3.023303675552428404e-01,
					1.111595886843614323e-01,
					2.521003182371493456e-01,
					-1.949715094101340807e-01,
					-2.762616380610153494e-03,
					-2.346665545344819026e-01,
					1.225124134876468263e-01,
					9.788671347308010307e-02
			};
			double inter3[] = {
					-1.011108463352825781e+00
			};

			for (unsigned int i = 0; i < sizeof(inter1) / sizeof(inter1[0]); i++) {
				intercept1.push_back(inter1[i]);
			}

			for (unsigned int i = 0; i < sizeof(inter2) / sizeof(inter2[0]); i++) {
				intercept2.push_back(inter2[i]);
			}

			for (unsigned int i = 0; i < sizeof(inter3) / sizeof(inter3[0]); i++) {
				intercept3.push_back(inter3[i]);
			}

			double __coe1[4][10] = {
					{7.962965161679927961e-01,  1.400469522233614983e-01,  -1.871509900583334884e+00, -6.479274695892466296e-01, 2.329160146651637842e+00,  -1.966201516821039608e+00, -1.388746484799119676e-02, -2.914981297754998812e-01, 2.265864852792748962e+00,  -8.398266708595225616e-01},
					{-5.687837468825841514e-01, -1.094977121212667714e-01, 1.189621881968769002e-01,  4.288042928195133219e-01,  3.501238752343057477e-03,  -7.918139665036739716e-01, 2.991241279598212954e-01,  -5.976763114905947472e-01, 5.265103497781518094e-01,  -4.137790775084633776e-01},
					{4.877718933804204293e-01,  6.389528330340684681e-01,  1.899763375230980045e-01,  -9.060456878894420640e-01, 7.980940474727904466e-02,  -3.339844503083820859e-01, -1.858868635576908512e-01, 1.138277374281083887e+00,  3.302615364402879949e-01,  1.111498137088792415e+00},
					{4.571135707831097128e-01,  5.828625011634043229e-01,  9.668751950314738997e-01,  -2.248534764107340891e-02, -3.293042080509198666e-01, 1.101452979886475170e+00,  -1.181120811507350377e+00, 8.430802385267434362e-02,  -6.292887915504192797e-01, 5.730210867135188124e-01} };
			for (unsigned int i = 0; i < 4; i++) {
				MyArray row;
				for (unsigned int j = 0; j < 10; j++) {
					row.push_back(__coe1[i][j]);
				}
				coefs1.push_back(row);
			}

			double __co2[10][8] = { {-2.014581191694493345e-01, -6.573677000940985060e-01, -8.745400286688436164e-01, -6.761542730044505234e-01, 1.170899714383282664e+00,  -8.375283493949565727e-01, -7.298965070090440710e-01, 1.457067636374890507e-01},
								   {-1.219349601935016736e+00, -4.792550015092902210e-02, -4.514251359572853950e-01, 8.952831490914840984e-01,  2.657120207055146399e-01,  -1.115141416746424419e+00, 3.274111657277638532e-01,  -2.110708037006982507e-01},
								   {1.785500485894782330e-01,  1.901316304725668704e+00,  -8.599907850070339643e-01, 1.338105961389493670e+00,  1.690408015651097273e-01,  -5.539972098447273341e-01, 1.598548068661804100e+00,  -1.834844173493489938e+00},
								   {6.883200517884209280e-01,  1.176208257335477292e+00,  8.364619287026093808e-01,  6.072387273398932583e-01,  -8.849478530983079239e-01, 1.531898578811448919e-01,  1.202297984737115355e+00,  -9.873660345847462549e-01},
								   {-1.914774314731173266e-01, -2.665623099915415128e+00, 7.307805214954613549e-01,  -2.092508357306940514e+00, -7.295243810215673586e-02, -8.323286110970588014e-01, -3.397715626330876759e+00, 2.179912100756101978e+00},
								   {-6.851094310131885523e-01, 1.556665960171357277e+00,  -4.324190589413304808e-01, 1.100048299720671974e+00,  3.580867498217260581e-02,  -3.040056368162040723e-01, 1.923200488065827551e+00,  -1.504237608669585669e+00},
								   {5.111891630763629735e-01,  -1.231872455724699195e-01, 6.542795930973058782e-01,  -7.076240345835901335e-01, -2.413699328927100540e-01, 2.945414422388077935e-01,  1.839933075488205116e-02,  8.432332935972827181e-01},
								   {-4.622084463399445675e-01, -1.932642800353647217e-01, -6.472236222807041806e-01, -1.311986377981122776e-01, 3.839825721874697839e-01,  8.981486374184202703e-02,  1.843098392065983804e-01,  -5.913753484718674569e-01},
								   {3.444227346333808004e-01,  -9.833747540950522614e-01, -1.631096484122119550e-01, -4.793055078550070847e-01, -2.748428118491945127e-01, 3.154662794718876562e-01,  -1.007864567758937957e+00, 7.691606055536319708e-01},
								   {-1.936416415100597754e-01, 7.439855094984271222e-01,  -8.730576260172386860e-01, 2.756009309936287566e-01,  -1.816196594019239552e-01, -2.567071334850794598e-02, -6.886251825425708517e-02, -5.344097848109149451e-01} };
			for (unsigned int i = 0; i < 10; i++) {
				MyArray row;
				for (unsigned int j = 0; j < 8; j++) {
					row.push_back(__co2[i][j]);
				}
				coefs2.push_back(row);
			}
			double co3[8] = { 1.328342030872854629e+00,
							 -1.215076119481532269e+00,
							 1.110261708069264275e+00,
							 -1.313865935308337285e+00,
							 -2.180676549931963581e+00,
							 1.877658238189321649e+00,
							 -7.572702244205192779e-01,
							 7.840679478467689201e-01 };
			MyArray row;
			for (unsigned int i = 0; i < 8; i++) {
				row.push_back(co3[i]);
			}
			coefs3.push_back(row);
		}
		template <class T>
		T** alloc(int row, int col) {
			T** fArr = new T*[row];
			for (int i = 0; i < row; i++)
				fArr[i] = new T[col];
			return fArr;
		}

		//deallocate the array
		template <class T>
		void dealloc(T**arr, int row, int col) {
			
			for (int i = 0; i < row; i++)
				delete[] arr[i];
			delete[] arr;
		}

		TwoArray matrixT(TwoArray arr) {
			TwoArray result;
			const int len = arr.size();
			if (len == 0)return result;
			const int row = arr.at(0).size();
			//FLOAT fArr[row][len];
			FLOAT** fArr = alloc<FLOAT>(row, len);


			for (unsigned int i = 0; i < len; i++) {
				for (unsigned int j = 0; j < row; j++) {
					fArr[j][i] = arr.at(i).at(j);
				}
			}
			for (unsigned int i = 0; i < row; i++) {
				MyArray tmpRow;
				for (unsigned int j = 0; j < len; j++) {
					tmpRow.push_back(fArr[i][j]);
				}
				result.push_back(tmpRow);
			}
			dealloc<FLOAT>(fArr, row, len);
			return result;
		}

		TwoArray arrMulMax(TwoArray arr1, TwoArray arr2) {
			TwoArray arrResult;
			int m = arr1.size();
			if (m == 0)return arrResult;
			int p = arr1.at(0).size();

			int q = arr2.size();
			if (q == 0) return arrResult;
			int n = arr2.at(0).size();
			if (p != q) {
				return arrResult;
			}

			//            LOGE("arrMulMax %d * %d,   %d * %d", m, p, q, n);
			FLOAT sum = 0;
			double** result = alloc<double>(m, n);
			for (unsigned int c = 0; c < m; c++) {
				for (unsigned int d = 0; d < n; d++) {
					for (unsigned int k = 0; k < p; k++) {
						sum = sum + arr1.at(c).at(k) * arr2.at(k).at(d);
					}

					result[c][d] = sum;
					sum = 0;
				}
			}

			for (unsigned int c = 0; c < m; c++) {
				MyArray row;
				for (unsigned int d = 0; d < n; d++)
					row.push_back(result[c][d]);
				arrResult.push_back(row);
			}
			dealloc<double>(result, m, n);
			return arrResult;
		}

		MyArray flatten(MyArray arr, FLOAT level) {
			MyArray data;
			int len = arr.size();
			for (unsigned int i = 0; i < len; i++) {
				if (arr.at(i) >= level)data.push_back(1);
				else data.push_back(0);
			}
			return data;
		}

		TwoArray arrTanh(TwoArray arr) {
			TwoArray result;
			int m = arr.size();
			if (m == 0)return result;
			int n = arr.at(0).size();
			for (unsigned int i = 0; i < m; i++) {
				MyArray row;
				for (unsigned int j = 0; j < n; j++) {
					row.push_back(tanh(arr.at(i).at(j)));
				}
				result.push_back(row);
			}
			return result;
		}

		TwoArray arrSum(TwoArray arr, MyArray arr1) {
			TwoArray result;
			int m = arr.size();
			if (m == 0)return result;
			int n = arr.at(0).size();
			for (unsigned int i = 0; i < m; i++) {
				MyArray row;
				for (unsigned int j = 0; j < n; j++) {
					row.push_back(arr.at(i).at(j) + arr1.at(j));
				}
				result.push_back(row);
			}
			return result;
		}

		MyArray logistic(MyArray x) {
			MyArray data;
			int len = x.size();
			for (unsigned int i = 0; i < len; i++) {
				FLOAT ex = (1 + exp(-x.at(i)));
				if (ex != 0) {
					data.push_back(1.f / ex);
				}
				else {
					data.push_back(0);
				}
			}
			return data;
		}

		TwoArray logistic(TwoArray arr) {
			TwoArray result;
			// try {
				int m = arr.size();
				if (m == 0)return result;
				int n = arr.at(0).size();
				for (unsigned int i = 0; i < m; i++) {
					MyArray row;
					for (unsigned int j = 0; j < n; j++) {
						FLOAT ex = (1 + exp(-arr.at(i).at(j)));
						if (ex != 0) {
							row.push_back(1.f / ex);
						}
						else {
							row.push_back(0);
						}
					}
					result.push_back(row);
				}
			// }
			// catch (const std::exception &e) {
			// 	LOGE("logistic error %s", e.what());
			// }
			return result;
		}


		FLOAT pow2(FLOAT f) {
			return f * f;
		}

		FLOAT arrMulSum(MyArray arr, MyArray arr2) {
			FLOAT res = 0;
			int len = arr.size();
			for (unsigned int i = 0; i < len; i++) {
				res += (arr.at(i) * arr2.at(i));
			}
			return res;
		}

		MyArray arrDiv(MyArray arr, FLOAT fValue) {
			MyArray data;
			if (fValue == 0)
				return data;
			int len = arr.size();
			for (unsigned int i = 0; i < len; i++) {
				data.push_back(arr.at(i) / fValue);
			}
			return data;
		}

		MyArray arrSub(MyArray arr, FLOAT fValue) {
			MyArray data;

			int len = arr.size();
			for (unsigned int i = 0; i < len; i++) {
				data.push_back(arr.at(i) - fValue);
			}
			return data;
		}


		MyArray removeAt(MyArray arr, int position) {
			MyArray data;
			int len = arr.size();
			for (unsigned int i = 0; i < len; i++) {
				if (position != i) {
					data.push_back(arr.at(i));
				}
			}
			return data;
		}

		int maxPosition(MyArray arr) {
			int len = arr.size();
			if (len == 0)
				return -1;
			FLOAT max = arr.at(0);
			int pos = 0;

			for (unsigned int i = 1; i < len; i++) {
				if (max < arr.at(i)) {
					max = arr.at(i);
					pos = i;
				}
			}
			return pos;
		}

		int minPosition(MyArray arr) {
			int len = arr.size();
			if (len == 0)
				return -1;
			FLOAT min = arr.at(0);
			int pos = 0;

			for (unsigned int i = 1; i < len; i++) {
				if (min > arr.at(i)) {
					min = arr.at(i);
					pos = i;
				}
			}
			return pos;
		}

		FLOAT arrMin(MyArray arr) {
			int len = arr.size();
			if (len == 0)
				return -1;
			FLOAT tmp = arr.at(0);

			for (unsigned int i = 1; i < len; i++) {
				if (tmp > arr.at(i))tmp = arr.at(i);
			}
			return tmp;
		}

		FLOAT arrMax(MyArray arr) {
			int len = arr.size();
			if (len == 0)
				return -1;
			FLOAT tmp = arr.at(0);

			for (unsigned int i = 1; i < len; i++) {
				if (tmp < arr.at(i))tmp = arr.at(i);
			}
			return tmp;
		}


		FLOAT mean(MyArray arr) {
			int len = arr.size();
			if (len == 0)
				return 0;
			FLOAT sum = 0;

			for (unsigned int i = 0; i < len; i++) {
				sum += arr.at(i);
			}
			return sum / len;
		}


		MyArray del_outlier(MyArray rr_window, int delsize) {
			if (delsize % 2 != 0)
				LOGE("error delsize mod 2 != 0");
			//delete upper delsize/2 values.
			MyArray rr_window_before = rr_window;
			for (int i = 0; i < delsize / 2; i++) {
				int maxP = maxPosition(rr_window_before);
				if (maxP >= 0 && maxP < rr_window_before.size()) {
					rr_window_before = removeAt(rr_window_before, maxP);
				}
			}

			for (int i = 0; i < delsize / 2; i++) {
				int minP = minPosition(rr_window_before);
				if (minP >= 0 && minP < rr_window_before.size()) {
					rr_window_before = removeAt(rr_window_before, minP);
				}
			}
			return rr_window_before;
		}

		FLOAT RMSSD(MyArray rr_window, int delsize) {
			MyArray rr;
			if (delsize != 0) {
				rr = del_outlier(rr_window, delsize);
			}
			else {
				rr = rr_window;
			}
			//    show(rr_window, "rr_window");
			//    show(rr,"rr");

			MyArray rr_j_1;
			int rrSize = rr.size();
			for (unsigned int i = 1; i < rrSize; i++) {
				rr_j_1.push_back(rr.at(i));
			}
			//    show(rr_window,"rr_window");
			//    show(rr, "rr");
			MyArray rr_j;
			for (unsigned int i = 0; i < rrSize - 1; i++) {
				rr_j.push_back(rr.at(i));
			}

			MyArray distance;
			for (unsigned int i = 0; i < rrSize - 1; i++) {
				distance.push_back(pow2(rr_j.at(i) - rr_j_1.at(i)));
			}
			FLOAT sum_sqared = sum(distance);

			FLOAT cons = 0;
			if (rrSize != 1)
				cons = sqrt(1.0 / (rrSize - 1.0));

			FLOAT rmssd = cons * sum_sqared;
			FLOAT rr_mean = mean(rr);

			return rmssd / rr_mean;
		}

		MyArray make_RMSSD_list(TwoArray rr_matrix, int delsize) {
			MyArray rmssd_list;
			if (rr_matrix.size() == 0) {
				LOGE("not enough :make_RMSSD_list");
				return rmssd_list;
			}
			if (rr_matrix.at(0).size() < delsize) {
				delsize = 0;
			}

			int len = rr_matrix.size();
			for (unsigned int i = 0; i < len; i++) {
				rmssd_list.push_back(RMSSD(rr_matrix[i], delsize));
			}
			return rmssd_list;
		}

		//make_TPR_list
		FLOAT turningpoint_num(MyArray x) {
			int N = 0;
			int len = x.size();
			for (int i = 1; i < len; i++) {

				if ((x[i - 1] < x[i] && x[i + 1] < x[i]) || (x[i - 1] > x[i] && x[i + 1] > x[i]))
					N += 1;
			}
			return N;
		}

		MyArray make_TPR_list(TwoArray rr_matrix) {
			MyArray TP_num_list;
			int len = rr_matrix.size();
			for (unsigned int i = 0; i < len; i++) {
				TP_num_list.push_back(turningpoint_num(rr_matrix[i]));
			}

			int TPR_len = rr_matrix.at(0).size() - 2;

			MyArray output_TPR_list = arrDiv(TP_num_list, float(TPR_len));
			return output_TPR_list;
		}

		// make_SE_list
		MyArray histogram(MyArray arr, int bins = 10, bool density = false) {
			FLOAT min = arrMin(arr);
			FLOAT max = arrMax(arr);

			MyArray data;
			if (bins == 0) return data;
			double* result = new double[bins];
			memset(result, 0, (size_t)(bins * sizeof(double)));

			MyArray range;
			for (unsigned int i = 0; i < bins; i++) {
				range.push_back(min + (max - min) * i / bins);
			}
			range.push_back(max + 0.000001);
			int len = arr.size();
			for (unsigned int i = 0; i < len; i++) {
				for (unsigned int j = 0; j < bins; j++) {
					if (range.at(j) <= arr.at(i) && arr.at(i) < range.at(j + 1)) {
						result[j] = result[j] + 1;
					}
				}
			}


			for (unsigned int j = 0; j < bins; j++) {
				data.push_back(result[j]);
			}
			return data;
		}

		FLOAT SE(MyArray rr_window, int bins, int delsize) {
			MyArray rr;
			if (delsize != 0) {
				rr = del_outlier(rr_window, delsize);
			}
			else {
				rr = rr_window;
			}

			MyArray rr_hist_num = histogram(rr, bins, false);
			MyArray p_i = arrDiv(rr_hist_num, float(rr.size()));
			//    with warnings.catch_warnings():
			//    warnings.simplefilter("ignore")
			//    log_p_i = np.log(p_i)
			MyArray log_p_i;
			int p_i_Size = p_i.size();
			for (unsigned int i = 0; i < p_i_Size; i++) {
				if (p_i.at(i) > 0)
					log_p_i.push_back(log(p_i.at(i)));
				else {
					log_p_i.push_back(0);
				}
			}
			MyArray term1 = arrSub(log_p_i, log(1.0 / float(bins)));
			FLOAT SE = arrMulSum(p_i, term1);
			return SE;
		}

		MyArray make_SE_list(TwoArray rr_matrix, int delsize, int bins = 16) {
			MyArray output_SE_list;

			if (rr_matrix.size() == 0)return output_SE_list;
			if (rr_matrix.at(0).size() < delsize) {
				delsize = 0;
			}

			int len = rr_matrix.size();
			for (unsigned int i = 0; i < len; i++) {
				output_SE_list.push_back(SE(rr_matrix[i], bins, delsize));
			}
			return output_SE_list;
		}
		//make_mean_list

		MyArray make_mean_list(TwoArray rr_matrix) {
			MyArray mean_list;
			int len = rr_matrix.size();
			for (unsigned int i = 0; i < len; i++) {
				mean_list.push_back(mean(rr_matrix.at(i)));
			}
			return mean_list;
		}

		TwoArray rr_matrix_to_RMSSD_TPR_SE_MEAN(TwoArray rr_matrix) {
			MyArray RMSSD = make_RMSSD_list(rr_matrix, 8);
			// show(RMSSD, "RMSSD");
			MyArray TPR = make_TPR_list(rr_matrix);
			//show(TPR, "TPR");
			MyArray SE = make_SE_list(rr_matrix, 8, 16);
			// show(SE, "SE");
			MyArray MEAN = make_mean_list(rr_matrix);
			// show(MEAN, "MEAN");

			TwoArray RMSSD_TPR_SE_MEAN;
			RMSSD_TPR_SE_MEAN.push_back(RMSSD);
			RMSSD_TPR_SE_MEAN.push_back(TPR);
			RMSSD_TPR_SE_MEAN.push_back(SE);
			RMSSD_TPR_SE_MEAN.push_back(MEAN);
			return RMSSD_TPR_SE_MEAN;
		}

		// -------------------------------------------- other ----------------------------------

		MyArray predict(TwoArray X_array) {

			TwoArray h1 = arrTanh(arrSum(arrMulMax(matrixT(X_array), coefs1), intercept1));
			//            show(h1, "h1");
			TwoArray h2 = arrTanh(arrSum(arrMulMax(h1, coefs2), intercept2));
			//            show(h2, "h2");

			TwoArray arrMul3 = arrMulMax(h2, matrixT(coefs3));
			//            LOGE("coefs3 size  %d * %d", coefs3.size(), coefs3.at(0).size());
			//            show(arrMul3, "arrMul3");
			TwoArray arrSum3 = arrSum(arrMul3, intercept3);
			//            show(arrSum3, "arrSum3");
			//    MyArray output = logistic(arrSum3);
			TwoArray output = logistic(arrSum3);
			//            show(output, "output");
			//            LOGE("output size %d %d", output.size(), output.at(0).size());

			MyArray outputLiner;
			if (output.size() == 0) {
				LOGE("no out put data");
			}
			for (unsigned int i = 0; i < output.size(); i++) {
				outputLiner.push_back(output.at(i).at(0));
			}
			MyArray y_hat = flatten(outputLiner, 0.5);
			//            show(y_hat, "y_hat");

			return y_hat;
		}


		MyArray run_af_detect(TwoArray rr_matrix) {
			if (coefs1.size() == 0) {
				printf("is first for af");
				init();
			}


			TwoArray X = rr_matrix_to_RMSSD_TPR_SE_MEAN(rr_matrix);
			//            LOGE("rr_matrix size => %d * %d   ,X size => %d * %d ", rr_matrix.size(),
			//                 rr_matrix.at(0).size(), X.size(), X.at(0).size());
			//            show(X, "X");
			MyArray y_hat = predict(X);
			//            show(y_hat, "y_hat");
			return y_hat;
		}


		//        void begin_af_detect() {
		//
		//            double mData[1][64] = {
		//                    {7.358099999999999641e-01, 7.421799999999999509e-01, 7.287599999999999634e-01, 7.223199999999999621e-01, 7.277700000000000280e-01, 7.464300000000000379e-01, 8.226900000000000324e-01, 8.130199999999999649e-01, 8.130199999999999649e-01, 7.284000000000000474e-01, 7.222300000000000386e-01, 7.096000000000000085e-01, 7.161999999999999478e-01, 7.817300000000000360e-01, 7.829300000000000148e-01, 7.925799999999999512e-01, 7.739000000000000323e-01, 7.976199999999999957e-01, 8.184099999999999708e-01, 7.737699999999999578e-01, 7.523800000000000487e-01, 7.262399999999999967e-01, 7.205399999999999583e-01, 7.364399999999999835e-01, 7.530000000000000027e-01, 7.575100000000000167e-01, 7.994599999999999485e-01, 7.883499999999999952e-01, 8.024000000000000021e-01, 7.602499999999999813e-01, 7.775100000000000344e-01, 8.035499999999999865e-01, 8.086100000000000509e-01, 8.094799999999999773e-01, 7.465699999999999559e-01, 7.390499999999999847e-01, 7.178900000000000281e-01, 8.047400000000000109e-01, 7.945699999999999985e-01, 8.573499999999999455e-01, 7.683799999999999519e-01, 7.576800000000000201e-01, 7.675300000000000455e-01, 7.853799999999999670e-01, 8.070899999999999741e-01, 7.421699999999999964e-01, 7.421699999999999964e-01, 7.358000000000000096e-01, 7.517300000000000093e-01, 7.627199999999999536e-01, 7.769899999999999585e-01, 7.778699999999999504e-01, 7.850000000000000311e-01, 7.883200000000000207e-01, 7.955999999999999739e-01, 7.955600000000000449e-01, 7.746300000000000407e-01, 7.641400000000000414e-01, 7.543900000000000050e-01, 7.645199999999999774e-01, 7.645199999999999774e-01, 7.600999999999999979e-01, 7.764999999999999680e-01, 7.945200000000000040e-01}
		//            };
		//            TwoArray testData_2_x_60;
		//            for (int i = 0; i < 610; i++) {
		//                MyArray row;
		//                for (int j = 0; j < 64; j++) {
		//                    row.push_back(mData[i][j]);
		//                }
		//                testData_2_x_60.push_back(row);
		//            }
		//            run_af_detect(testData_2_x_60);
		//        }

		MyArray input_rri(MyArray rri) {
			// try {
				//                LOGD("af for rri    %d,      %f", rri.size(), rri.at(0));
				TwoArray twoArray;
				twoArray.push_back(rri);
				return run_af_detect(twoArray);
			// }
			// catch (const std::exception &e) {
			// 	LOGE("on af_detect error  %s", e.what());
			// }
			// MyArray nullArr;
			// return nullArr;
		}

		MyArray input_rriTwo(TwoArray TwoRRI) {
			MyArray nullArr;
			// try {
				if (TwoRRI.size() == 0)return nullArr;
				return run_af_detect(TwoRRI);
			// }
			// catch (const std::exception &e) {
			// 	LOGE("on af_detect error  %s", e.what());
			// }

			// return nullArr;
		}


	};
}
#endif
