var bindings = require('bindings');
var calm_af = bindings('calm_af');

module.exports = calm_af;