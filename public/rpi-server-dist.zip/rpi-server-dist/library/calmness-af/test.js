// test.js
const addon = require('./build/Release/calm_af');

// for (var i = 0; i < 10000; i++) {
//     var calm = addon.add(0.45);
//     if (calm != -1)
//         console.log('calm', calm, i);
// }

for (var i = 0; i < 30000; i++) {
    var arr = getARR_rri64();

    var is_af = addon.addAF(arr);
    console.log('isAF', is_af, i);
}


function getARR_rri64() {
    arr = [];
    for (var i = 0; i < 64; i++) {
        arr.push(0.5);
    }
    return arr;
}