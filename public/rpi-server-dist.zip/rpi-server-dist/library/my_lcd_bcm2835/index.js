var bindings = require('bindings');
var my_lcd_bcm2835 = bindings('my_lcd_bcm2835');

module.exports = my_lcd_bcm2835;