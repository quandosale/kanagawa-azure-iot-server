module.exports = {
    COOKIE_PATH: "/usr/myjsonfile_v0.6.json",
    DEFAULT_SERVER_URL: 'https://kanagawa-web.azurewebsites.net',
    // DEFAULT_SERVER_URL: 'http://192.168.3.5:8080',
    GatewayStatus: {
        NOT_REGISTERED: -1,
        NOT_APPROVED: 0,
        APPROVED: 1,
        ERROR: -2
    },
    VERSION: 1
}