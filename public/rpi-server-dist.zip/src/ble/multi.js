// [BEGIN] CONFIGURE for Web server
var keys = Object.keys || require('object-keys');
var Logger = require('../lib/util').Logger;
var path = require('path');
const express = require('express');
const app = express();
const WebSocket = require('ws');
var WebSocketServer = require('ws').Server;
const http = require('http');
var server = require('http').createServer();

const EcgSender = require('./ecg-send').EcgSender;
const AF_Calc = require('./af_calc').AF_Calc;

var af_calc = new AF_Calc();

var ecgSender;

const FoundDevices = require('./found-devices').FoundDevices;
var foundDevices = new FoundDevices;
var foundDevicesNoRegistered = new FoundDevices;

var arr_connectedDevices = {};

var lcd_lib = require('../lcd_lib');

var wss = new WebSocketServer({
    server: server
});

// Broadcast to all.
wss.broadcast = function broadcast(data) {
    wss.clients.forEach(function each(client) {

        if (client.readyState === WebSocket.OPEN) {
            try {
                // console.log('sending data ' + data);
                client.send(data);
            } catch (e) {
                console.error(e);
            }
        }
    });
};

wss.on('connection', function (ws) {
    var id = setInterval(function () {}, 100);
    console.log('started client interval');
    ws.on('close', function () {
        console.log('stopping client interval');
        clearInterval(id);
    });
});
var startEcgChartServer = function () {
    app.use(express.static(path.join(__dirname, '../public')));
    server.on('request', app);
    server.listen(8081, function () {
        console.log('Listening on http://localhost:8081');
    });
}

// [END] CONFIGURE for Web server

// [BEGIN] for Ble management
const async = require('async');
const noble = require('noble');

var ECG_SERVICE_UUID = '1977';
var ECG_NOTIFY_CHAR = '1028';
var DESCRIPTOR_UUID = '2901';
var HEARTRATE_SERVICE_UUID = '180d';
var HEARTRATE_NOTIFY_CHAR = '2a37';

var SCANNING_DURATION = 4 * 1000;
var CONNECTING_DURATION = 6 * 1000;

var isScanning = false;

var registeredDevices = [];

var isRegistered = function (peripheral) {
    try {
        if (registeredDevices == undefined || registeredDevices == null) return false;
        // Logger.LOGD(`isRegistered from ${registeredDevices.length}`);
        for (var i = 0; i < registeredDevices.length; i++) {
            if (peripheral.id == registeredDevices[i].mac) {
                return true;
            }
        }
    } catch (err) {}
    return false;
}


var startScanningForGet = function (callback) {
    // if (!isScanning) {
    //     console.log('start scanning...');
    //     noble.startScanning();
    // }

    setTimeout(function () {
        console.log(foundDevices.length());
        // if (foundDevices.length == 0) {
        // startScanningDuration();
        // return;
        // }

        // noble.stopScanning(function (err) {
        uploadScanedDevice(callback);
        // });

    }, SCANNING_DURATION);
}

var uploadScanedDevice = function (callback) {
    var arr_foundDevices = [];
    for (var i = 0; i < foundDevices.length(); i++) {
        var peripheral = foundDevices.at(i);
        console.log(peripheral)
        arr_foundDevices.push({
            mac: peripheral.id,
            name: peripheral.advertisement.localName
        });
    }

    for (var i = 0; i < foundDevicesNoRegistered.length(); i++) {
        var peripheral = foundDevicesNoRegistered.at(i);
        console.log(peripheral)
        arr_foundDevices.push({
            mac: peripheral.id,
            name: peripheral.advertisement.localName
        });
    }

    callback(arr_foundDevices);
}

//
var startScanningDuration = function () {
    // lcd_lib.showRegisteredDevices(registeredDevices);
    // noble.on('stateChange', function (state) {
    //     console.log('stateChange', state);
    //     if (state === 'poweredOn') {
    if (global.displayObj != null) {
        global.displayObj.updateDeviceConnectStatus(keys(arr_connectedDevices));

        global.displayObj.arrRegistered = registeredDevices;
        if (global.displayObj.displayIndex == 1) {
            global.displayObj.displayDevicesMac();
        }
        if (global.displayObj.displayIndex == 2) {
            global.displayObj.displayDevicesName();
        }
    } else {
        console.log('displayObj == null')
    }

    if (!isScanning) {
        console.log('start scanning...');
        noble.startScanning();
    }

    setTimeout(function () {
        // if (foundDevices.isEmpty()) {
        //     startScanningDuration();
        //     return;
        // }

        noble.stopScanning(function (err) {
            connectWithFoundDevice();
        });

    }, SCANNING_DURATION);
    //     } else {
    //         console.log('stopScanning...');
    //         noble.stopScanning();
    //     }
    // });
}

noble.on('scanStart', function () {
    isScanning = true;
    Logger.LOG_BLE('on scanStart');
});

noble.on('scanStop', function () {
    isScanning = false;
    Logger.LOG_BLE('on scanStop');
});

noble.on('warning', function (message) {
    Logger.LOG_BLE(message);
});

noble.on('discover', function (peripheral) {
    var advertisement = peripheral.advertisement;
    var localName = advertisement.localName;
    if (!localName) return;
    if (!localName.toLocaleLowerCase().includes('calm')) return;
    var isRegisteredDevice = isRegistered(peripheral);
    Logger.LOG_BLE(`discovered '${peripheral.id}',  isRegistered: ${isRegisteredDevice}`);
    if (isRegisteredDevice) {
        if (foundDevices.exist(peripheral.id)) return;
        foundDevices.push(peripheral);
    } else {
        if (foundDevicesNoRegistered.exist(peripheral.id)) return;
        foundDevicesNoRegistered.push(peripheral);
    }

});




function connectWithFoundDevice() {
    console.log("connect with found device ", foundDevices.length());
    // if (foundDevices.length == 0) return;
    for (var i = 0; i < foundDevices.length(); i++) {
        var peripheral = foundDevices.at(i);
        // if (!peripheral.id.includes("e294"))
        connectWith(peripheral);
    }
    setTimeout(function () {
        startScanningDuration();
    }, CONNECTING_DURATION);
}

function connectWith(peripheral) {
    // console.log(peripheral);
    var state = peripheral.state;

    if (state != "disconnected") return;
    console.log('connecting... with ' + peripheral.id, "state = '" + state + "'");
    peripheral.on('disconnect', function () {
        Logger.LOG_BLE(`on Disconnected: ${peripheral.id}`);
        if (arr_connectedDevices[peripheral.id]) delete arr_connectedDevices[peripheral.id];
        ecgSender.nConnected--;
    });

    peripheral.connect(function (error) {
        // noble.startScanning();
        if (error) {
            console.log('peripheral connect error', error);
            return;
        }
        ecgSender.nConnected++;
        foundDevices.remove(peripheral.id);

        arr_connectedDevices[peripheral.id] = peripheral;
        Logger.LOG_BLE(`${peripheral.id} connected`);
        //[BEGIN connected]
        peripheral.discoverServices([], function (error, services) {
            var serviceIndex = 0;

            async.whilst(function () {
                    return (serviceIndex < services.length);
                },
                function (callback) {
                    var service = services[serviceIndex];
                    service.discoverCharacteristics([], function (error, characteristics) {
                        var characteristicIndex = 0;

                        async.whilst(function () {
                                return (characteristicIndex < characteristics.length);
                            },
                            function (callback) {
                                var characteristic = characteristics[characteristicIndex];
                                var characteristicInfo = '  ' + characteristic.uuid;
                                if (characteristic.uuid == ECG_NOTIFY_CHAR) {

                                    characteristic.on('data', (data, isNotification) => onNotify(characteristic, data, isNotification, peripheral));
                                    characteristic.subscribe(function (error) {
                                        Logger.LOG_BLE(`ecg notification on ${peripheral.id}`);
                                    });
                                }
                                if (characteristic.uuid == HEARTRATE_NOTIFY_CHAR) {
                                    characteristic.on('data', (data, isNotification) => onHeartRateNotify(characteristic, data, isNotification));
                                    characteristic.subscribe(function (error) {
                                        Logger.LOG_BLE(`HeartRate notification on ${peripheral.id}`);
                                    });
                                }

                                if (characteristic.name) {
                                    characteristicInfo += ' (' + characteristic.name + ')';
                                }

                                async.series([
                                    function (callback) {
                                        characteristic.discoverDescriptors(function (error, descriptors) {
                                            async.detect(
                                                descriptors,
                                                function (descriptor, callback) {
                                                    return callback(descriptor.uuid === DESCRIPTOR_UUID);
                                                },
                                                function (userDescriptionDescriptor) {
                                                    if (userDescriptionDescriptor) {
                                                        userDescriptionDescriptor.readValue(function (error, data) {
                                                            if (data) {
                                                                characteristicInfo += ' (' + data.toString() + ')';
                                                            }
                                                            callback();
                                                        });
                                                    } else {
                                                        callback();
                                                    }
                                                });
                                        });
                                    },
                                    function (callback) {
                                        characteristicInfo += '\n    properties  ' + characteristic.properties.join(', ');

                                        if (characteristic.properties.indexOf('read') !== -1) {
                                            characteristic.read(function (error, data) {
                                                if (data) {
                                                    var string = data.toString('ascii');

                                                    characteristicInfo += '\n    value       ' + data.toString('hex') + ' | \'' + string + '\'';
                                                }
                                                callback();
                                            });
                                        } else {
                                            callback();
                                        }
                                    },
                                    function () {
                                        // console.log(characteristicInfo);
                                        characteristicIndex++;
                                        callback();
                                    }
                                ]); //async.series
                            },
                            function (error) {
                                serviceIndex++;
                                callback();
                            }); //async.whilst(characteristic)
                    });
                },
                function (err) {
                    if (err) {
                        Logger.LOG_BLE(err);
                        peripheral.disconnect();
                    }
                }
            );
        }); //async.whilst(service)
        //[END connected]
    });
}

var time = 0;
const onHeartRateNotify = (characteristic, data, isNotification) => {

    // console.log('-----------------------------------------')
    var flags = data.readUInt8(0);
    var heartRate = 0;
    if (flags & 0x01) {
        // uint16
        heartRate = data.readUInt16LE(1);
    } else {
        // uint8
        heartRate = data.readUInt8(1);
    }
    // console.log('heartRate', heartRate);
    heartRate = Math.min(heartRate, 200);
    heartRate = Math.max(heartRate, 0);

    ecgSender.setHeartRate(heartRate, characteristic._peripheralId);

    var isAF = af_calc.add_hr(heartRate, characteristic._peripheralId);
    ecgSender.setAF(isAF, characteristic._peripheralId);
}

var rssiObj = {};
var timerIndex = 0;
const onNotify = (characteristic, data, isNotification, peripheral) => {
    timerIndex++;
    timerIndex = timerIndex % 1000;

    if (timerIndex == 0) {
        if (global.displayObj != null) {
            global.displayObj.updateDeviceConnectStatus(keys(arr_connectedDevices));
        } else {
            console.log('displayObj == null         2');
        }
    }

    var indexRssi = rssiObj["index"] || 0;
    if (indexRssi % (50 * 10)) {
        if (peripheral != null)
            peripheral.updateRssi(function (error, rssi) {
                // console.log(peripheral.uuid + ' RSSI:' + peripheral.rssi + ' update RSSI + ' + rssi + ' : Error :' + error);
                if (!error) {
                    rssiObj[characteristic._peripheralId] = rssi;
                }
            });
    }

    rssiObj["index"] = indexRssi + 1;

    var arr_ecg = [];
    var isSensorDetected = false;

    for (var i = 0; i < 5; i++) {

        var byte1 = data.readUInt8(1 + i * 2) & 0x00FF;
        var byte2 = data.readUInt8(1 + i * 2 + 1) & 0x00FF;
        var ecgTrans = ecgTransform(byte1, byte2);
        var ecg = ecgTrans.ecg;
        isSensorDetected = ecgTrans.isSensor;
        try {
            wss.broadcast(JSON.stringify({
                humidity: ecg,
                temperature: ecg,
                time: time++,
                id: characteristic._peripheralId
            }));
            arr_ecg.push(ecg);

        } catch (err) {
            console.error('error', err);
        }
    } // end for i = 5

    var accX = bytesToInt(data.readUInt8(11), data.readUInt8(12));
    var accY = bytesToInt(data.readUInt8(13), data.readUInt8(14));
    var accZ = bytesToInt(data.readUInt8(15), data.readUInt8(16));
    accX = accTransform(accX);
    accY = accTransform(accY);
    accZ = accTransform(accZ);

    var temperature = data.readUInt8(17) + 20;
    var battery = batteryTransform(data.readUInt8(18));
    ecgSender.add(arr_ecg, isSensorDetected, temperature, battery, accX, accY, accZ, rssiObj[characteristic._peripheralId], characteristic._peripheralId);
}
// [END] for Ble management
var batteryTransform = function (byte1) {
    var fvolt = byte1 * 600 * 114 / 14 / 255;
    //        Log.i("battery1", "" + fvolt);
    var nPercent = 0;
    if (fvolt > 4200) {
        nPercent = 100;
    } else if (fvolt < 3600)
        nPercent = 0;
    else {
        nPercent = ((fvolt - 3600) / 600 * 100);
    }
    return Math.floor(nPercent);
}
var bytesToInt = function (byte1, byte2) {
    var value = byte1 + byte2 * 256;
    return value;
}
var accTransform = function (accItem) {
    if (accItem > 2047)
        return ((accItem - 2048) / 500) - 4.096;
    else
        return (accItem) / 500;
}
var ecgTransform = function (byte1, byte2) {
    var ecgVal = byte1 + byte2 * 256;
    var isSensorDetected = ((ecgVal & 0x8000) != 0);

    ecgVal = ecgVal & 0x0fff;

    if (ecgVal <= 0) {
        ecgVal = 10;
    }

    return {
        ecg: ecgVal,
        isSensor: isSensorDetected
    };
}

var addDevice = function (_registeredDevices) {
    registeredDevices = _registeredDevices;
    console.log('addDevice:registeredDevices', registeredDevices);
    if (ecgSender != undefined)
        ecgSender.NEED_CONNECT = registeredDevices.length;
    return isStart;
};

var removeDevice = function (deviceMac) {
    ecgSender.NEED_CONNECT = registeredDevices.length
    //If connected ? disconnect
    if (arr_connectedDevices[deviceMac] == null || arr_connectedDevices[deviceMac] == undefined) return;
    var connectedPeripheral = arr_connectedDevices[deviceMac];
    try {
        connectedPeripheral.disconnect(function (error) {
            if (error) Logger.LOGE(error);
            else Logger.LOGD(`Successfully Disconnected: ${connectedPeripheral.id}`);
        });
    } catch (err) {
        Logger.LOGE(err);
    }
};

var isStart = false;

var entry = function (devices, client) {
    if (global.displayObj == null) {
        global.displayObj = new lcd_lib.InfoObj();
    }

    // setInterval(function () {
    //     global.displayObj.showInfoService()
    // }, 5000);

    global.displayObj.connected = true;

    try {
        require('events').EventEmitter.prototype._maxListeners = 100;
    } catch (e) {

    }

    isStart = true;
    startEcgChartServer();

    registeredDevices = devices;
    Logger.LOGD('Connecting with ');
    Logger.LOGD(devices);

    ecgSender = new EcgSender(client);
    ecgSender.NEED_CONNECT = registeredDevices.length
    // noble.on('stateChange', function (state) {
    //     console.log('stateChange', state);
    // if (state === 'poweredOn') {

    startScanningDuration();
    // } else {
    // console.log('stopScanning...');
    // noble.stopScanning();
    // }
    // });
};

module.exports = {
    entry: entry,
    removeDevice: removeDevice,
    addDevice: addDevice,
    startScanningForGet: startScanningForGet
}