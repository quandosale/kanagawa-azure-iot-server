var FoundDevices = function () {
    this.foundDevices = [];
};

FoundDevices.prototype.push = function (peripheral) {
    this.foundDevices.push(peripheral);
};

FoundDevices.prototype.length = function () {
    return this.foundDevices.length;
};

FoundDevices.prototype.indexOfFound = function (id) {
    for (var i = 0; i < this.foundDevices.length; i++) {
        var peripheral = this.foundDevices[i];
        if (peripheral.id == id) return i;
    }
    return -1;
};

FoundDevices.prototype.exist = function (id) {
    var index = this.indexOfFound(id);
    return index != -1;
};

FoundDevices.prototype.remove = function (id) {
    var index = this.indexOfFound(id);
    if (index != -1)
        this.foundDevices.splice(index, 1);
};

FoundDevices.prototype.at = function (index) {
    return this.foundDevices[index];
};

FoundDevices.prototype.isEmpty = function () {
    return this.foundDevices.length == 0;
};

module.exports = {
    FoundDevices: FoundDevices
};