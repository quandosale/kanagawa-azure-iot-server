var my_lcd = require("my_lcd_bcm2835");

var lcd_lib = require('./lcd_lib');

var BACKLIGHT_DURATION = 120 * 1000;
var backlight_on = function () {
    my_lcd.backlighton();
};
var backlight_off = function () {
    my_lcd.backlightoff();
};


var LONG_DURATION = 5000;

var secondFormat = function (second) {
    var text = '' + Math.round(second / 1000) + ' seconds';
    return text;
}
var startKeyListener = function () {
    if (global.displayObj == null) global.displayObj = new lcd_lib.InfoObj();
    var key1_before_time = -1;
    var key3_before_time = -1;

    var backlight_on_time = new Date().getTime();
    var currentBackLight = true;
    setInterval(function () {
        var key1 = my_lcd.read_Key1();
        if (key1 == 0) {
            if (key1_before_time == -1) {
                key1_before_time = new Date().getTime();
                global.displayObj.display();
            }
        }

        if (key1 == 1) {
            key1_before_time = -1;
        }

        var key3 = my_lcd.read_Key3();

        if (key3 == 0) {
            if (key3_before_time == -1) {
                key3_before_time = new Date().getTime();
            } else {
                var duration = new Date().getTime() - key3_before_time;
                if (duration >= LONG_DURATION) {
                    console.log('key3 duration: ', duration);
                    lcd_lib.show_lines("Rebooting ...");
                    require('child_process').exec('sudo /sbin/shutdown -r now', function (msg) {
                        console.log(msg)
                    });
                } else {
                    var text = secondFormat(duration);
                    lcd_lib.show_lines(text);
                }
            }
        }
        if (key3 == 1) {
            if (key3_before_time != -1) {
                global.displayObj.display();
            }
            key3_before_time = -1;
        }


        //backlight
        var key2 = my_lcd.read_Key2();
        if (key2 == 0) {
            if (!currentBackLight) {
                backlight_on();
                currentBackLight = true;
            }

            backlight_on_time = new Date().getTime();
        }
        var backlight_delay = new Date().getTime() - backlight_on_time;
        console.log(backlight_delay, backlight_delay > BACKLIGHT_DURATION);
        if (backlight_delay > BACKLIGHT_DURATION) {
            if (currentBackLight) {
                backlight_off();
                currentBackLight = false;
            }

        }
    }, 100);
}

module.exports = {
    startKeyListener: startKeyListener
};