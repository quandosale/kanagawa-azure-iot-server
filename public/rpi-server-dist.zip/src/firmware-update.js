var request = require("request");
var http = require('http');
var fs = require('fs');
var url = require('url');

var Util = require('./lib/util');
var Logger = require('./lib/util').Logger;
var config = require('./config');
var VERSION = config.VERSION;
var Message = require('azure-iot-device').Message;

var update = function (client, isMust, callback) {
    var cookie = Util.read_cookie();
    if (cookie == null) {
        Logger.LOGE('Cannot find cookie');
        return callback(false, 'Cannot find cookie');
    }
    var url = `${cookie.server_url}/iot/firmware-version`;
    console.log(url)
    var self = this;
    request.get({
            url: url,
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
            },
            json: true
        },
        function (error, response, body) {
            if (!error && response.statusCode == 200) {
                if (body == undefined) {
                    Logger.LOGE("Cannot get Firmware Version");
                    // return process.exit(0);
                }
                var RPI_GATEWAY_VERSION = body.RPI_GATEWAY_VERSION;
                var checksum = body.checksum;
                Logger.LOGE("firmware version = ", body);
                if (RPI_GATEWAY_VERSION > VERSION || isMust) {
                    Logger.LOGE("New Version abailable\n New Version Downloading ...");
                    cookie.checksum = checksum;
                    downloadFirmware(client, cookie);
                    return callback(true, "Downloading ...");
                } else {
                    return callback(false, "Already updated");
                }
            } else {
                Logger.LOGE("Request Error", error, response.statusCode);
                return callback(false, "Request Error");
            }
        });
};

function printResultFor(op, msg) {
    return function printResult(err, res) {
        if (err) console.log(op + ' error: ' + err.toString());
        if (res) {
            console.log(op + ' status: ' + res.constructor.name, msg);
        }
    };
}
var reporting = function (client, cookie, totalLen, receivedSize, percent, isComplete) {
    if (client == null) return;
    var deviceId = cookie != null ? cookie.deviceId : 'Unnown';
    if (isComplete) {
        var json = {
            TAG: "FIRMWARE_DOWNLOADING",
            data: {
                completed: true,
                totalLen: totalLen,
                emitter: deviceId
            },
        };
        var message = new Message(JSON.stringify(json));
        client.sendEvent(message, printResultFor('download completed firmware', 'isCompleted'));
        return;
    }
    var json = {
        TAG: "FIRMWARE_DOWNLOADING",
        data: {
            completed: false,
            percent: percent,
            totalLen: totalLen,
            receivedSize: receivedSize,
            emitter: deviceId
        }
    };

    var message = new Message(JSON.stringify(json));
    client.sendEvent(message, printResultFor('downloading ... firmware', '' + percent));
}

var downloadFirmware = function (client, cookie) {
    var FIRMWARE_PATH = '/home/firm.zip';
    if (fs.existsSync(FIRMWARE_PATH))
        fs.unlinkSync(FIRMWARE_PATH);
    var file = fs.createWriteStream(FIRMWARE_PATH);
    var file_url = `${cookie.server_url}/iot/firmware-download`;
    var options = {
        host: url.parse(file_url).host,
        port: 80,
        path: url.parse(file_url).pathname
    };
    var receivedSize = 0;
    http.get(options, function (res) {
        var totalLen = parseInt(res.headers['content-length'], 10);
        var prePercent = 0;
        res.on('data', function (data) {
            receivedSize += data.length;
            file.write(data);
            var percent = (receivedSize / totalLen) * 100;

            if ((percent - prePercent) > 2) {
                console.log('Downloading ..., packet ()', percent);
                reporting(client, cookie, totalLen, receivedSize, percent, false);
                prePercent = percent;
            }
        }).on('end', function () {
            file.end();


            console.log('Download Completed');

            Logger.LOGE('Rebooting ...');
            reporting(client, cookie, totalLen, receivedSize, 100, true);
            Util.write_cookie(cookie);
            require('child_process').exec('sudo /sbin/shutdown -r now', function (msg) {
                console.log(msg)
            });
        });
    });
};

module.exports = {
    update: update
}