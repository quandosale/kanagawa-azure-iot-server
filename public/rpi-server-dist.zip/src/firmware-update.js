var request = require("request");
var http = require('http');
var fs = require('fs');
var url = require('url');

var Util = require('./lib/util');
var Logger = require('./lib/util').Logger;
var config = require('./config');
var VERSION = config.VERSION;

var update = function (isMust, callback) {
    var cookie = Util.read_cookie();
    if (cookie == null) {
        Logger.LOGE('Cannot find cookie');
        return callback(false, 'Cannot find cookie');
    }
    var url = `${cookie.server_url}/iot/firmware-version`;
    console.log(url)
    var self = this;
    request.get({
            url: url,
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
            },
            json: true
        },
        function (error, response, body) {
            if (!error && response.statusCode == 200) {
                if (body == undefined) {
                    Logger.LOGE("Cannot get Firmware Version");
                    // return process.exit(0);
                }
                var RPI_GATEWAY_VERSION = body.RPI_GATEWAY_VERSION;
                Logger.LOGE("firmware version = ", body);
                if (RPI_GATEWAY_VERSION > VERSION || isMust) {
                    Logger.LOGE("New Version abailable\n New Version Downloading ...");
                    return callback(true, "Downloading ...");
                    downloadFirmware(cookie);
                } else {
                    return callback(false, "Already updated");
                }
            } else {
                Logger.LOGE("Request Error", error, response.statusCode);
                return callback(false, "Request Error");
            }
        });
};

var downloadFirmware = function (cookie) {
    var FIRMWARE_PATH = '/home/firm.zip';
    fs.unlinkSync(FIRMWARE_PATH);
    var file = fs.createWriteStream(FIRMWARE_PATH);
    var file_url = `${cookie.server_url}/iot/firmware-download`;
    var options = {
        host: url.parse(file_url).host,
        port: 80,
        path: url.parse(file_url).pathname
    };
    var receivedSize = 0;
    http.get(options, function (res) {
        var totalLen = parseInt(res.headers['content-length'], 10);

        res.on('data', function (data) {
            receivedSize += data.length;
            console.log('Downloading ..., packet ()', (receivedSize / totalLen) * 100);
            file.write(data);
        }).on('end', function () {
            file.end();


            console.log('Download Completed');

            Logger.LOGE('Rebooting ...');

            require('child_process').exec('sudo /sbin/shutdown -r now', function (msg) {
                console.log(msg)
            });
        });
    });
};
module.exports = {
    update: update
}