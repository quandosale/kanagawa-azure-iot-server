// addon.cc
#include <node.h>
#include "calm/MyArr.h"
#include "calm/CalmnessA.h"
#include "calm/AF_detect.h"

using namespace Calm;
using namespace AF_Module;
CalmnessA calmnessA;
AF_Module::AF_Detect mAF_Detect;
namespace demo
{

using v8::Array;
using v8::Exception;
using v8::FunctionCallbackInfo;
using v8::Handle;
using v8::Isolate;
using v8::Local;
using v8::Number;
using v8::Object;
using v8::String;
using v8::Value;

// This is the implementation of the "add" method
// Input arguments are passed using the
// const FunctionCallbackInfo<Value>& args struct

double tmp = 0;
void Add(const FunctionCallbackInfo<Value> &args)
{
  Isolate *isolate = args.GetIsolate();

  // Check the number of arguments passed.
  if (args.Length() < 1)
  {
    // Throw an Error that is passed back to JavaScript
    isolate->ThrowException(Exception::TypeError(
        String::NewFromUtf8(isolate, "Wrong number of arguments")));
    return;
  }

  // Check the argument types
  if (!args[0]->IsNumber())
  {
    isolate->ThrowException(Exception::TypeError(
        String::NewFromUtf8(isolate, "Wrong arguments")));
    return;
  }

  // Perform the operation
  double value = args[0]->NumberValue();
  MyArray arr_rri;
  arr_rri.push_back((FLOAT)value);
  MyArray result = calmnessA.calmnessDataSrc(arr_rri);
  if (result.size() == 0)
    tmp = -1;
  else
    tmp = result[0];
  Local<Number> num = Number::New(isolate, tmp);

  // Set the return value (using the passed in
  // FunctionCallbackInfo<Value>&)
  args.GetReturnValue().Set(num);
}

void Add_FOR_AF(const FunctionCallbackInfo<Value> &args)
{
  Isolate *isolate = args.GetIsolate();

  // Check the number of arguments passed.
  if (args.Length() < 1)
  {
    // Throw an Error that is passed back to JavaScript
    isolate->ThrowException(Exception::TypeError(
        String::NewFromUtf8(isolate, "Wrong number of arguments")));
    return;
  }

  // Check the argument types
  if (!args[0]->IsArray())
  {
    isolate->ThrowException(Exception::TypeError(
        String::NewFromUtf8(isolate, "Wrong arguments, must array")));
    return;
  }
  Local<Array> jsArray = Local<Array>::Cast(args[0]);
  int len = jsArray->Length();

  // if(len < 64){
  //   isolate->ThrowException(Exception::TypeError(
  //       String::NewFromUtf8(isolate, "rri must be large than 63")));
  //   return;
  // }
  MyArray my_rri_array;
  for (unsigned int i = 0; i < len; i++)
  {
    Handle<Value> val = jsArray->Get(i);
    FLOAT rri = val->NumberValue();
    my_rri_array.push_back(rri);
  }

  int n_af_result = 3;
  //        LOGD("af for rri %d  -----               called", mArrRRI.size());
  MyArray afResult = mAF_Detect.input_rri(my_rri_array);
  // printf("afResult.size() = %d, rri size = %d\n", afResult.size(), len);
  if (afResult.size() > 0)
  {
    n_af_result = afResult.at(0);
  }
  Local<Number> num = Number::New(isolate, n_af_result);
  args.GetReturnValue().Set(num);
}

void Init(Local<Object> exports)
{
  NODE_SET_METHOD(exports, "add", Add);
  NODE_SET_METHOD(exports, "addAF", Add_FOR_AF);
}

NODE_MODULE(NODE_GYP_MODULE_NAME, Init)

} // namespace demo