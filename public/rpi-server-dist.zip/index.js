#!/usr/bin/env node

'use strict';
var readline = require('readline');
var chalk = require('chalk');
var program = require('commander');

var GatewayStatus = require('./src/config').GatewayStatus;
var stop_function = require('./src/cli/stop').stop_function;
var log = console.log;
var Util = require('./src/lib/util');
var Logger = Util.Logger;
var exec = require('child_process').exec;
var DEFAULT_SERVER_URL = require('./src/config').DEFAULT_SERVER_URL;
var exit = function () {
    process.exit(0);
};

var key_lib = require('./src/key_lib');
var lcd_lib = require('./src/lcd_lib');
global.display_number = 100;
process.on('exit', (code) => {
    // lcd_lib.clear();
    lcd_lib.showIpFromStatus(false);
});

var keyboard_ServerUrlAndCheck = function () {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    Logger.LOGD(`\nPlease Input Server Url : (${DEFAULT_SERVER_URL})`);
    Logger.LOGR(`(To use default server, Press 'Enter')`);
    rl.question('', (server_url) => {
        rl.close();
        if (server_url == '.exit') {
            exit();
        }
        Logger.LOGD('Checking Server Validation');
        var CalmStationService = require('./src/CalmStationService').CalmStationService;
        var calmStationService = new CalmStationService();
        if (server_url.length == 0) server_url = DEFAULT_SERVER_URL;
        calmStationService.checkServer(server_url, function (success, error) {
            if (success)
                keyboard_LicenceAndCheck(server_url);
            else {
                Logger.LOGE('Invalid Server, Please input server url again.');
                Logger.LOGR('(To exit, press ^C again or type .exit)');

                keyboard_ServerUrlAndCheck();
            }
        });
    });
};

var keyboard_LicenceAndCheck = function (server_url) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question('\nPlease Input Your Licence Key : ', (licence) => {
        rl.close();
        var CalmStationService = require('./src/CalmStationService').CalmStationService;
        var calmStationService = new CalmStationService();

        calmStationService.checkLicence(server_url, licence, function (success, info, error) {
            //console.log('checkLicence', success, iotConnectionString, error);
            if (success && info != null) {
                keyboard_GatewayNameAndCreate(server_url, info.iotConnectionString, info.iotHostName);
            } else {
                Logger.LOGE('Invalid Licence, Please input again.');
                Logger.LOGR('(To exit, press ^C again or type .exit)');

                keyboard_LicenceAndCheck(server_url);
            }
        });
    });
};

var keyboard_GatewayNameAndCreate = function (server_url, iotConnectionString, iotHostName) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question('\nGateway Name : (Gateway) ', (gatewayName) => {
        rl.close();
        if (gatewayName.length == 0) gatewayName = "Gateway";
        var CalmStationService = require('./src/CalmStationService').CalmStationService;
        var calmStationService = new CalmStationService();
        var tmp_cookie = {
            deviceId: "",
            primaryKey: "",
            deviceName: gatewayName,
            iotConnectionString: iotConnectionString,
            iotHostName: iotHostName,
            server_url: server_url
        };
        calmStationService.create(tmp_cookie);
    });
};

program
    .version('0.4')
    // .command('start', 'Start the server')
    // .command('init', 'Create Device & make cookie')
    // .command('remove', 'Remove cookie')

    .description(chalk.red('Execute the given remote cmd'))
    .action(function (cmd, options) {
        // log('ka "%s" using %s mode', cmd, options.exec_mode);
    }).on('--help', function () {});

program
    .arguments('<command>')
    // .option('-s, --service', 'Flag for service(using Daemon)')
    .action(function (command) {
        command = ("" + command).toLowerCase();
        switch (command) {
            case 'start':
                lcd_lib.init();
                lcd_lib.showLogo();
                setTimeout(function () {
                    key_lib.startKeyListener();
                    lcd_lib.start_step();
                    var start_function = require('./src/cli/start').start_function;
                    start_function(program);
                }, 2000)

                break;
            case 'init':
                // lcd_lib.init_step();
                var CalmStationService = require('./src/CalmStationService').CalmStationService;
                var calmStationService = new CalmStationService();

                var cookie = calmStationService.readCookie();

                if (cookie == null) {
                    keyboard_ServerUrlAndCheck();
                    return
                }

                calmStationService.checkAPI(function (status, gateway, error) {
                    if (status == GatewayStatus.NOT_REGISTERED) {
                        keyboard_GatewayNameAndCreate(cookie.server_url, cookie.iotConnectionString, cookie.iotHostName);
                        return
                    }
                    if (status == GatewayStatus.APPROVED) {
                        Logger.LOGD("\nYour Gateway already Approved");
                        if (gateway) {
                            var info =
                                `\t server   : ${cookie.server_url}\n` +
                                `\t name     : ${gateway.name}\n` +
                                `\t id       : ${gateway.deviceId}\n` +
                                `\t created  : ${gateway.createdAt}\n`;

                            Logger.LOGD(info);
                        }

                    }
                    if (status == GatewayStatus.ERROR) {
                        if (error) Logger.LOGE(error);
                    }

                    exit();
                });

                break;
            case 'remove':
                var cookie = Util.deleteCookie();
                if (cookie) {
                    Logger.LOGD('Successfuly removed');
                } else {
                    Logger.LOGE('Cannot find cookie');
                }
                break;
        }
    })
    .parse(process.argv);