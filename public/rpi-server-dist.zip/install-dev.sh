#!/bin/bash

# Functions ==============================================

# return 1 if global command line program installed, else 0
# example
# echo "node: $(program_is_installed node)"
function program_is_installed {
  # set to 1 initially
  local return_=1
  # set to 0 if not found
  type $1 >/dev/null 2>&1 || { local return_=0; }
  # return value
  echo "$return_"
}

# return 1 if local npm package is installed at ./node_modules, else 0
# example
# echo "gruntacular : $(npm_package_is_installed gruntacular)"
function npm_package_is_installed {
  # set to 1 initially
  local return_=1
  # set to 0 if not found
  ls node_modules | grep $1 >/dev/null 2>&1 || { local return_=0; }
  # return value
  echo "$return_"
}

# display a message in red with a cross by it
# example
# echo echo_fail "No"
function echo_main {
  # echo first argument in red
  printf "\033[1;33m ${1}\n"
  # reset colours back to normal
  printf "\033[0m"
}
# display a message in red with a cross by it
# example
# echo echo_fail "No"
function echo_fail {
  # echo first argument in red
  printf "\e[31m✘ ${1}"
  # reset colours back to normal
  printf "\033[0m"
  sudo apt-get --assume-yes install npm #
}

# display a message in green with a tick by it
# example
# echo echo_fail "Yes"
function echo_pass {
  # echo first argument in green
  printf "\e[32m✔ ${1}"
  # reset colours back to normal
  printf "\033[0m"
}

# echo pass or fail
# example
# echo echo_if 1 "Passed"
# echo echo_if 0 "Failed"
function echo_if {
  if [ $1 == 1 ]; then
    echo_pass $2
  else
    echo_fail $2
  fi
}

# ============================================== Functions

function echo_if {
  if [ $1 == 1 ]; then
    echo_pass $2
  else
    echo_fail $2 #
    
  fi
}
echo_main "0: change Logo splash" #
sudo cp ./src/assets/splash.png /usr/share/plymouth/themes/pix/splash.png #
sudo cp ./src/assets/calm-logo.bmp /usr/calm-logo.bmp #
echo_main "1: apt-get -y update" #
sudo apt-get -y update #

echo_main "2: install npm" #
echo "npm    $(echo_if $(program_is_installed npm))" #

echo_main "3: install library for bluetooth" #install library for bluetooth
sudo apt-get --assume-yes install bluetooth bluez libbluetooth-dev libudev-dev #
echo_main "4: install bcm2835" #
tar -xvzf ./library/my_lcd_bcm2835/bcm2835-1.55.tar.gz #
#
cd ./bcm2835-1.55/ #
./configure #
make #
sudo make check #
sudo make install #
cd .. #
#
#echo_main "5: install the serve" #install the serve
#sudo npm install #
echo_main "6: init server(register device to iothub)" #init server(register device to iothub)
sudo node index.js init #
echo_main "7: start server" #
sudo node index.js start # start server
